export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyA00j1iy3YFBPmCBcswDoU4PzZNuw9A1tE",
    authDomain: "mcdonalds-f0c00-80100.firebaseapp.com",
    projectId: "mcdonalds-f0c00-80100",
    storageBucket: "mcdonalds-f0c00-80100.firebasestorage.app",
    messagingSenderId: "200707193000",
    appId: "1:200707193000:web:205f48a029f57217a86a9d",
    measurementId: "G-C0DJDRMED2"
  }
};