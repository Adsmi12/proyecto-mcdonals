import { inject } from '@angular/core';
import { FirebaseService } from '../services/firebase';
import { Producto } from '../interfaces/producto.interface';

export async function migrateProductsToFirestore() {
  const firebaseService = inject(FirebaseService);

  const productosHardcodeados: any[] = [
    {
      id: 1,
      nombre: 'Big Mac',
      descripcion: 'Dos hamburguesas de carne 100% vacuno, salsa especial, lechuga, queso, pepinillos y cebolla en pan con sésamo',
      precio: 6590,
      imagen: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Big Mac.png/200/200/original?country=cl',
      categoria: 'Hamburguesas'
    },
    {
      id: 2,
      nombre: 'Cuarto de Libra',
      descripcion: 'Carne 100% vacuno, queso cheddar, cebolla, pepinillos, ketchup y mostaza',
      precio: 6990,
      imagen: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Cuarto de Libra con Queso.png/200/200/original?country=cl',
      categoria: 'Hamburguesas'
    },
    {
      id: 3,
      nombre: 'McPollo',
      descripcion: 'Pollo crujiente, lechuga fresca y mayonesa en un suave pan',
      precio: 5690,
      imagen: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$qvX3kXZy/200/200/original?country=cl',
      categoria: 'Pollo y McNuggets'
    },
    {
      id: 4,
      nombre: 'McNífica',
      descripcion: 'Carne 100% vacuno, lechuga, tomate, cebolla, pepinillos, queso y salsa especial',
      precio: 6990,
      imagen: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$McNifica.png/200/200/original?country=cl',
      categoria: 'Hamburguesas'
    },
    {
      id: 5,
      nombre: 'Doble Cuarto de Libra',
      descripcion: 'Dos carnes 100% vacuno, doble queso cheddar, cebolla, pepinillos, ketchup y mostaza',
      precio: 8990,
      imagen: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Doble Cuarto de Libra con Queso.png/200/200/original?country=cl',
      categoria: 'Hamburguesas'
    },
    {
      id: 6,
      nombre: 'McRoyal Deluxe',
      descripcion: 'Carne 100% vacuno, lechuga, tomate, cebolla, pepinillos, queso y mayonesa',
      precio: 4790,
      imagen: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Hamburguesa con Queso.png/200/200/original?country=cl',
      categoria: 'Hamburguesas'
    },
    {
      id: 7,
      nombre: 'Triple Mac',
      descripcion: 'Tres carnes 100% vacuno, triple queso, lechuga, cebolla, pepinillos y salsa especial',
      precio: 9490,
      imagen: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Big Mac.png/200/200/original?country=cl',
      categoria: 'Hamburguesas'
    },
    {
      id: 8,
      nombre: 'Hamburguesa Simple',
      descripcion: 'Carne 100% vacuno, pepinillos, cebolla, ketchup y mostaza',
      precio: 2490,
      imagen: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Hamburguesa regular.png/200/200/original?country=cl',
      categoria: 'Hamburguesas'
    },
    {
      id: 9,
      nombre: 'Cheeseburger',
      descripcion: 'Carne 100% vacuno, queso derretido, pepinillos, cebolla, ketchup y mostaza',
      precio: 2990,
      imagen: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Hamburguesa con Queso.png/200/200/original?country=cl',
      categoria: 'Hamburguesas'
    },
    {
      id: 10,
      nombre: 'Papas Medianas',
      descripcion: 'Deliciosas papas fritas doradas y crujientes',
      precio: 2390,
      imagen: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV_370_14Feb25.png',
      categoria: 'Para Acompañar'
    },
    {
      id: 11,
      nombre: 'Papas Grandes',
      descripcion: 'Deliciosas papas fritas doradas y crujientes tamaño grande',
      precio: 2490,
      imagen: 'https://d2umxhib5z7frz.cloudfront.net/Chile/380_05Mar25.png',
      categoria: 'Para Acompañar'
    },
    {
      id: 12,
      nombre: 'Empanadas',
      descripcion: 'Porcion de 3 empanadas',
      precio: 2190,
      imagen: 'https://d2umxhib5z7frz.cloudfront.net/Chile/2220_05Mar25.png',
      categoria: 'Para Acompañar'
    },
    {
      id: 13,
      nombre: 'Chicken kids 4 piezas',
      descripcion: 'Tiernos trozos de pechuga de pollo empanizados',
      precio: 1860,
      imagen: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV_12409_31102025.png',
      categoria: 'Pollo y McNuggets'
    },
    {
      id: 14,
      nombre: 'McNuggets 10 piezas',
      descripcion: 'Tiernos trozos de pechuga de pollo empanizados',
      precio: 4990,
      imagen: 'https://d2umxhib5z7frz.cloudfront.net/Chile/310_05Mar25.png',
      categoria: 'Pollo y McNuggets'
    },
    {
      id: 15,
      nombre: 'McNuggets 20 piezas',
      descripcion: 'Tiernos trozos de pechuga de pollo empanizados',
      precio: 9590,
      imagen: 'https://d2umxhib5z7frz.cloudfront.net/Chile/320_05Mar25.png',
      categoria: 'Pollo y McNuggets'
    },
    {
      id: 16,
      nombre: 'McPollo italiano',
      descripcion: 'Pollo crujiente, lechuga, tomate y mayonesa',
      precio: 6490,
      imagen: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV_1633_30072025.png',
      categoria: 'Pollo y McNuggets'
    },
    {
      id: 17,
      nombre: 'Coca Cola Mediana',
      descripcion: 'Refrescante Coca Cola',
      precio: 2090,
      imagen: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV_500.png',
      categoria: 'Bebidas'
    },
    {
      id: 18,
      nombre: 'Coca Cola Grande',
      descripcion: 'Refrescante Coca Cola tamaño grande',
      precio: 2190,
      imagen: 'https://d2umxhib5z7frz.cloudfront.net/Chile/570_mop_10.png',
      categoria: 'Bebidas'
    },
    {
      id: 19,
      nombre: 'Sprite sin azúcar grande',
      descripcion: 'Refrescante Sprite sin azúcar',
      precio: 2190,
      imagen: 'https://d2umxhib5z7frz.cloudfront.net/Chile/7087_mop_10.png',
      categoria: 'Bebidas'
    },
    {
      id: 20,
      nombre: 'Jugo de Manzana grande',
      descripcion: 'Jugo natural de manzana',
      precio: 2490,
      imagen: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV-108-20250814.png',
      categoria: 'Bebidas'
    },
    {
      id: 21,
      nombre: 'Fanta Zero grande',
      descripcion: 'Refrescante Fanta Zero sin azúcar',
      precio: 2190,
      imagen: 'https://d2umxhib5z7frz.cloudfront.net/Chile/600_mop_10.png',
      categoria: 'Bebidas'
    }
  ];

  // Convertir formato de productos hardcodeados a formato Firestore
  for (const prod of productosHardcodeados) {
    const producto: Producto = {
      nombre: prod.nombre,
      descripcion: prod.descripcion,
      precio: prod.precio,
      fotoUrl: prod.imagen,
      categoria: prod.categoria,
      ingredientes: [] // Se pueden agregar ingredientes manualmente después
    };

    try {
      await firebaseService.addProducto(producto);

    } catch (error) {

    }
  }


}
