export interface Ingrediente {
  nombre: string;
  imagenUrl?: string;
}

export interface Producto {
  id?: string;
  nombre: string;
  descripcion: string;
  fotoUrl?: string;
  categoria: string;
  precio: number;
  ingredientes: Ingrediente[];
  stock?: { [restaurantId: string]: number }; // Stock por restaurante
}