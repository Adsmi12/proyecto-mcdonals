import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FirebaseService } from '../services/firebase';
import { Producto } from '../interfaces/producto.interface';

@Component({
  selector: 'app-migrate',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div style="padding: 2rem; background: white; max-width: 800px; margin: 2rem auto; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
      <h2 style="color: #d41b1b; margin-bottom: 1rem;">Migración de Productos a Firestore</h2>
      
      <button 
        (click)="migrateProducts()" 
        [disabled]="isLoading"
        style="background: #d41b1b; color: white; border: none; padding: 1rem 2rem; border-radius: 8px; font-size: 1rem; cursor: pointer; margin-bottom: 1rem;">
        {{ isLoading ? 'Migrando...' : 'Migrar 21 Productos' }}
      </button>

      <div *ngIf="message" style="padding: 1rem; margin-top: 1rem; border-radius: 4px;"
           [style.background]="message.includes('Error') ? '#ffebee' : '#e8f5e9'"
           [style.color]="message.includes('Error') ? '#c62828' : '#2e7d32'">
        {{ message }}
      </div>

      <div *ngIf="logs.length > 0" style="margin-top: 1rem; max-height: 400px; overflow-y: auto; background: #f5f5f5; padding: 1rem; border-radius: 4px;">
        <div *ngFor="let log of logs" style="margin: 0.25rem 0; font-family: monospace; font-size: 0.9rem;">
          {{ log }}
        </div>
      </div>
    </div>
  `
})
export class MigrateComponent {
  private firebaseService = inject(FirebaseService);
  
  isLoading = false;
  message = '';
  logs: string[] = [];

  async migrateProducts() {
    this.isLoading = true;
    this.message = '';
    this.logs = [];

    const productos = [
      {
        nombre: 'Big Mac',
        descripcion: 'Dos hamburguesas de carne 100% vacuno, salsa especial, lechuga, queso, pepinillos y cebolla en pan con sésamo',
        precio: 6590,
        fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Big Mac.png/200/200/original?country=cl',
        categoria: 'Hamburguesas',
        ingredientes: []
      },
      {
        nombre: 'Cuarto de Libra',
        descripcion: 'Carne 100% vacuno, queso cheddar, cebolla, pepinillos, ketchup y mostaza',
        precio: 6990,
        fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Cuarto de Libra con Queso.png/200/200/original?country=cl',
        categoria: 'Hamburguesas',
        ingredientes: []
      },
      {
        nombre: 'McPollo',
        descripcion: 'Pollo crujiente, lechuga fresca y mayonesa en un suave pan',
        precio: 5690,
        fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$qvX3kXZy/200/200/original?country=cl',
        categoria: 'Pollo y McNuggets',
        ingredientes: []
      },
      {
        nombre: 'McNífica',
        descripcion: 'Carne 100% vacuno, lechuga, tomate, cebolla, pepinillos, queso y salsa especial',
        precio: 6990,
        fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$McNifica.png/200/200/original?country=cl',
        categoria: 'Hamburguesas',
        ingredientes: []
      },
      {
        nombre: 'Doble Cuarto de Libra',
        descripcion: 'Dos carnes 100% vacuno, doble queso cheddar, cebolla, pepinillos, ketchup y mostaza',
        precio: 8990,
        fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Doble Cuarto de Libra con Queso.png/200/200/original?country=cl',
        categoria: 'Hamburguesas',
        ingredientes: []
      },
      {
        nombre: 'McRoyal Deluxe',
        descripcion: 'Carne 100% vacuno, lechuga, tomate, cebolla, pepinillos, queso y mayonesa',
        precio: 4790,
        fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Hamburguesa con Queso.png/200/200/original?country=cl',
        categoria: 'Hamburguesas',
        ingredientes: []
      },
      {
        nombre: 'Triple Mac',
        descripcion: 'Tres carnes 100% vacuno, triple queso, lechuga, cebolla, pepinillos y salsa especial',
        precio: 9490,
        fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Big Mac.png/200/200/original?country=cl',
        categoria: 'Hamburguesas',
        ingredientes: []
      },
      {
        nombre: 'Hamburguesa Simple',
        descripcion: 'Carne 100% vacuno, pepinillos, cebolla, ketchup y mostaza',
        precio: 2490,
        fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Hamburguesa regular.png/200/200/original?country=cl',
        categoria: 'Hamburguesas',
        ingredientes: []
      },
      {
        nombre: 'Cheeseburger',
        descripcion: 'Carne 100% vacuno, queso derretido, pepinillos, cebolla, ketchup y mostaza',
        precio: 2990,
        fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Hamburguesa con Queso.png/200/200/original?country=cl',
        categoria: 'Hamburguesas',
        ingredientes: []
      },
      {
        nombre: 'Papas Medianas',
        descripcion: 'Deliciosas papas fritas doradas y crujientes',
        precio: 2390,
        fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV_370_14Feb25.png',
        categoria: 'Para Acompañar',
        ingredientes: []
      },
      {
        nombre: 'Papas Grandes',
        descripcion: 'Deliciosas papas fritas doradas y crujientes tamaño grande',
        precio: 2490,
        fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/380_05Mar25.png',
        categoria: 'Para Acompañar',
        ingredientes: []
      },
      {
        nombre: 'Empanadas',
        descripcion: 'Porcion de 3 empanadas',
        precio: 2190,
        fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/2220_05Mar25.png',
        categoria: 'Para Acompañar',
        ingredientes: []
      },
      {
        nombre: 'Chicken kids 4 piezas',
        descripcion: 'Tiernos trozos de pechuga de pollo empanizados',
        precio: 1860,
        fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV_12409_31102025.png',
        categoria: 'Pollo y McNuggets',
        ingredientes: []
      },
      {
        nombre: 'McNuggets 10 piezas',
        descripcion: 'Tiernos trozos de pechuga de pollo empanizados',
        precio: 4990,
        fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/310_05Mar25.png',
        categoria: 'Pollo y McNuggets',
        ingredientes: []
      },
      {
        nombre: 'McNuggets 20 piezas',
        descripcion: 'Tiernos trozos de pechuga de pollo empanizados',
        precio: 9590,
        fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/320_05Mar25.png',
        categoria: 'Pollo y McNuggets',
        ingredientes: []
      },
      {
        nombre: 'McPollo italiano',
        descripcion: 'Pollo crujiente, lechuga, tomate y mayonesa',
        precio: 6490,
        fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV_1633_30072025.png',
        categoria: 'Pollo y McNuggets',
        ingredientes: []
      },
      {
        nombre: 'Coca Cola Mediana',
        descripcion: 'Refrescante Coca Cola',
        precio: 2090,
        fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV_500.png',
        categoria: 'Bebidas',
        ingredientes: []
      },
      {
        nombre: 'Coca Cola Grande',
        descripcion: 'Refrescante Coca Cola tamaño grande',
        precio: 2190,
        fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/570_mop_10.png',
        categoria: 'Bebidas',
        ingredientes: []
      },
      {
        nombre: 'Sprite sin azúcar grande',
        descripcion: 'Refrescante Sprite sin azúcar',
        precio: 2190,
        fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/7087_mop_10.png',
        categoria: 'Bebidas',
        ingredientes: []
      },
      {
        nombre: 'Jugo de Manzana grande',
        descripcion: 'Jugo natural de manzana',
        precio: 2490,
        fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV-108-20250814.png',
        categoria: 'Bebidas',
        ingredientes: []
      },
      {
        nombre: 'Fanta Zero grande',
        descripcion: 'Refrescante Fanta Zero sin azúcar',
        precio: 2190,
        fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/600_mop_10.png',
        categoria: 'Bebidas',
        ingredientes: []
      }
    ];

    let successCount = 0;
    let errorCount = 0;

    for (const prod of productos) {
      try {
        await this.firebaseService.addProducto(prod as Producto);
        successCount++;
        this.logs.push(`✅ ${prod.nombre} - agregado correctamente`);
      } catch (error: any) {
        errorCount++;
        this.logs.push(`❌ ${prod.nombre} - Error: ${error.message}`);
      }
    }

    this.isLoading = false;
    this.message = `✅ Migración completada: ${successCount} productos agregados, ${errorCount} errores`;
  }
}
