import { Injectable, signal, computed } from '@angular/core';
import { ComboProduct } from '../interfaces/offer.interface';

export interface CartItem {
  id: string;
  nombre: string;
  precio: number;
  imagen: string;
  cantidad: number;
  ingredientesRemovidos?: string[];
  extrasAgregados?: { id: string; nombre: string; precio: number }[];
  precioUnitario?: number; // Precio por unidad con personalizaciones

  // Campos para combos
  isCombo?: boolean;
  comboProducts?: ComboProduct[];
  comboId?: string;
}

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private items = signal<CartItem[]>([]);

  // Computed signals
  cartItems = this.items.asReadonly();

  totalItems = computed(() =>
    this.items().reduce((sum, item) => sum + item.cantidad, 0)
  );

  totalPrice = computed(() =>
    this.items().reduce((sum, item) => {
      const precioItem = item.precioUnitario ?? item.precio;
      return sum + (precioItem * item.cantidad);
    }, 0)
  );

  addToCart(product: {
    id: string;
    nombre: string;
    precio: number;
    imagen: string;
    cantidad?: number;
    ingredientesRemovidos?: string[];
    extrasAgregados?: { id: string; nombre: string; precio: number }[];
    precioUnitario?: number;
  }) {
    const currentItems = this.items();
    const cantidad = product.cantidad ?? 1;

    // Para productos personalizados, siempre agregamos como item nuevo
    if (product.ingredientesRemovidos || product.extrasAgregados) {
      this.items.update(items => [
        ...items,
        {
          id: product.id,
          nombre: product.nombre,
          precio: product.precio,
          imagen: product.imagen,
          cantidad: cantidad,
          ingredientesRemovidos: product.ingredientesRemovidos,
          extrasAgregados: product.extrasAgregados,
          precioUnitario: product.precioUnitario
        }
      ]);
      return;
    }

    // Para productos sin personalización, buscamos si ya existe
    const existingItemIndex = currentItems.findIndex(item =>
      item.id === product.id &&
      !item.ingredientesRemovidos &&
      !item.extrasAgregados
    );

    if (existingItemIndex !== -1) {
      this.items.update(items =>
        items.map((item, index) =>
          index === existingItemIndex
            ? { ...item, cantidad: item.cantidad + cantidad }
            : item
        )
      );
    } else {
      this.items.update(items => [
        ...items,
        {
          id: product.id,
          nombre: product.nombre,
          precio: product.precio,
          imagen: product.imagen,
          cantidad: cantidad
        }
      ]);
    }
  }

  // Agregar combo al carrito
  addComboToCart(combo: {
    id: string;
    nombre: string;
    precio: number;
    imagen: string;
    comboProducts: ComboProduct[];
  }) {
    this.items.update(items => [
      ...items,
      {
        id: combo.id,
        nombre: combo.nombre,
        precio: combo.precio,
        imagen: combo.imagen,
        cantidad: 1,
        isCombo: true,
        comboProducts: combo.comboProducts,
        comboId: combo.id
      }
    ]);
  }

  removeFromCart(index: number) {
    this.items.update(items => items.filter((_, i) => i !== index));
  }

  updateQuantity(index: number, cantidad: number) {
    if (cantidad <= 0) {
      this.removeFromCart(index);
      return;
    }

    this.items.update(items =>
      items.map((item, i) =>
        i === index
          ? { ...item, cantidad }
          : item
      )
    );
  }

  clearCart() {
    this.items.set([]);
  }
}
