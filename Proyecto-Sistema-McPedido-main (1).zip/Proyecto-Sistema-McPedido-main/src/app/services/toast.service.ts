import { Injectable, signal } from '@angular/core';

export interface ToastMessage {
  text: string;
  type: 'success' | 'error' | 'info';
  duration?: number;
}

@Injectable({
  providedIn: 'root'
})
export class ToastService {
  toast = signal<ToastMessage | null>(null);
  private timeoutId: any;

  show(text: string, type: 'success' | 'error' | 'info' = 'success', duration: number = 3000) {
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }

    this.toast.set({ text, type, duration });

    this.timeoutId = setTimeout(() => {
      this.hide();
    }, duration);
  }

  hide() {
    this.toast.set(null);
  }
}
