import { Injectable, inject } from '@angular/core';
import { Firestore, collection, addDoc, collectionData, doc, deleteDoc, updateDoc } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { Producto } from '../interfaces/producto.interface';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {

  // inyeccion de firestore (app.config.ts)
  private firestore: Firestore = inject(Firestore);
  
  // referencia a los productos en la base de datos
  private productosRef = collection(this.firestore, 'productos');

  constructor() { }


  getProductos(): Observable<Producto[]> {
    return collectionData(this.productosRef, { idField: 'id' }) as Observable<Producto[]>;
  }

  // 2. crear producto (Create)
  addProducto(producto: Producto) {
    return addDoc(this.productosRef, producto);
  }

  // 3. editar producto (Update)
  updateProducto(producto: Producto) {
    const productoDocRef = doc(this.firestore, `productos/${producto.id}`);
    return updateDoc(productoDocRef, { ...producto });
  }

  // 4. eliminar producto (Delete)
  deleteProducto(id: string) {
    const productoDocRef = doc(this.firestore, `productos/${id}`);
    return deleteDoc(productoDocRef);
  }
}