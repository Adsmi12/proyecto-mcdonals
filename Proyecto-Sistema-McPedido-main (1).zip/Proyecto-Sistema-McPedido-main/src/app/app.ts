import { Component, signal } from '@angular/core';
import { RouterOutlet, Router, NavigationEnd } from '@angular/router';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './features/auth/components/login.component';
import { RegisterComponent } from './features/auth/components/register.component';
import { HeaderComponent } from './features/shared/components/header/header.component';
import { LoadingComponent } from './features/shared/components/loading/loading.component';
import { ToastComponent } from './features/shared/components/toast/toast.component';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, LoginComponent, RegisterComponent, CommonModule, HeaderComponent, LoadingComponent, ToastComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('McDonalds');
  protected showLogin = signal(false);
  protected showRegister = signal(false);
  isLoading = signal(true);

  constructor(private router: Router) {
    // Ocultar loading después de la primera navegación completa
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe(() => {
      setTimeout(() => this.isLoading.set(false), 500);
    });
  }

  openLogin() { this.showLogin.set(true); }
  closeLogin() { this.showLogin.set(false); }
  openRegister() { this.showRegister.set(true); }
  closeRegister() { this.showRegister.set(false); }
}
