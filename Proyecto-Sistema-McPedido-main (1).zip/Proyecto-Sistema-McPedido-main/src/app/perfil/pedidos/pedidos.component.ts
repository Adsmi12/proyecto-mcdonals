import { Component } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { OrderHistoryComponent } from '../../features/order/components/order-history/order-history.component';
import { inject } from '@angular/core';

@Component({
  selector: 'app-pedidos',
  standalone: true,
  imports: [CommonModule, OrderHistoryComponent],
  templateUrl: './pedidos.component.html',
  styleUrls: ['./pedidos.component.css']
})
export class PedidosComponent {
  private location = inject(Location);

  goBack() {
    this.location.back();
  }
}
