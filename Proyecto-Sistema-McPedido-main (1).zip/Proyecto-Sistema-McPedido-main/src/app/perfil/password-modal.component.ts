import { Component, output, Input } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule, AbstractControl, ValidationErrors } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Auth, EmailAuthProvider, linkWithCredential, reauthenticateWithCredential, updatePassword } from '@angular/fire/auth';
import { inject } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-password-modal',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './password-modal.component.html',
  styleUrl: './password-modal.component.css'
})
export class PasswordModalComponent {
  @Input() hasPassword: boolean = false;
  
  loading = false;
  error: string | null = null;
  success: string | null = null;
  form: any;
  private auth = inject(Auth);
  
  closeRequested = output<void>();
  passwordChanged = output<void>();

  constructor(private fb: FormBuilder) {
    this.initForm();
  }

  ngOnChanges() {
    this.initForm();
  }

  private initForm() {
    if (this.hasPassword) {
      // Formulario para cambiar contraseña (requiere contraseña actual)
      this.form = this.fb.group({
        currentPassword: ['', [Validators.required]],
        newPassword: ['', [Validators.required, Validators.minLength(6)]],
        confirmPassword: ['', [Validators.required]]
      }, { validators: this.passwordMatchValidator });
    } else {
      // Formulario para establecer contraseña por primera vez
      this.form = this.fb.group({
        newPassword: ['', [Validators.required, Validators.minLength(6)]],
        confirmPassword: ['', [Validators.required]]
      }, { validators: this.passwordMatchValidator });
    }
  }

  private passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
    const newPassword = control.get('newPassword');
    const confirmPassword = control.get('confirmPassword');

    if (!newPassword || !confirmPassword) {
      return null;
    }

    return newPassword.value === confirmPassword.value ? null : { passwordMismatch: true };
  }

  onClose() {
    this.closeRequested.emit();
  }

  async submit() {
    if (this.form.invalid || this.loading) {
      this.form.markAllAsTouched();
      return;
    }

    this.loading = true;
    this.error = null;
    this.success = null;

    try {
      const user = this.auth.currentUser;
      if (!user || !user.email) {
        throw new Error('No hay usuario autenticado');
      }

      const { currentPassword, newPassword } = this.form.value;

      if (this.hasPassword) {
        // Cambiar contraseña existente
        // Primero reautenticar con la contraseña actual
        const credential = EmailAuthProvider.credential(user.email, currentPassword);
        await reauthenticateWithCredential(user, credential);
        
        // Ahora actualizar a la nueva contraseña
        await updatePassword(user, newPassword);
        
        this.success = 'Contraseña actualizada correctamente';
      } else {
        // Vincular nueva credencial de contraseña
        const credential = EmailAuthProvider.credential(user.email, newPassword);
        await linkWithCredential(user, credential);
        
        this.success = 'Contraseña establecida correctamente. Ahora puedes iniciar sesión con tu email y contraseña.';
      }

      // Emitir evento de éxito
      this.passwordChanged.emit();

      // Cerrar modal después de 2 segundos
      setTimeout(() => {
        this.closeRequested.emit();
      }, 2000);

    } catch (err: any) {
      console.error('Error al procesar contraseña:', err);
      
      // Manejar errores específicos
      if (err.code === 'auth/wrong-password') {
        this.error = 'La contraseña actual es incorrecta';
      } else if (err.code === 'auth/weak-password') {
        this.error = 'La contraseña es demasiado débil';
      } else if (err.code === 'auth/requires-recent-login') {
        this.error = 'Por seguridad, necesitas volver a iniciar sesión para realizar esta acción';
      } else if (err.code === 'auth/provider-already-linked') {
        this.error = 'Ya tienes una contraseña establecida';
      } else {
        this.error = err?.message || 'Error al procesar la contraseña';
      }
    } finally {
      this.loading = false;
    }
  }
}
