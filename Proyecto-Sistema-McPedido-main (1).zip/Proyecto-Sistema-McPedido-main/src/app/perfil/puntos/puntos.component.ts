import { Component, inject, OnInit } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { AuthService } from '../../features/auth/auth.service';

@Component({
  selector: 'app-puntos',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './puntos.component.html',
  styleUrls: ['./puntos.component.css']
})
export class PuntosComponent implements OnInit {
  authService = inject(AuthService);
  private location = inject(Location);

  ngOnInit() {
    this.authService.refreshUserData();
  }

  goBack() {
    this.location.back();
  }
}
