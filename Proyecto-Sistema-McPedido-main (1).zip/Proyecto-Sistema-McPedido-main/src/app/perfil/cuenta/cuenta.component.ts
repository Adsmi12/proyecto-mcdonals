import { Component, inject } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../features/auth/auth.service';
import { Firestore, doc, updateDoc, deleteDoc } from '@angular/fire/firestore';
import { Auth, EmailAuthProvider, linkWithCredential, updatePassword, reauthenticateWithCredential, GoogleAuthProvider, FacebookAuthProvider, linkWithPopup, unlink } from '@angular/fire/auth';
import { Router } from '@angular/router';
import { PasswordModalComponent } from '../password-modal.component';

@Component({
  selector: 'app-cuenta',
  standalone: true,
  imports: [CommonModule, FormsModule, PasswordModalComponent],
  templateUrl: './cuenta.component.html',
  styleUrls: ['./cuenta.component.css']
})
export class CuentaComponent {
  loading = false;
  loadingUnlinkGoogle = false;
  loadingUnlinkFacebook = false;
  loadingGoogle = false;
  loadingFacebook = false;
  showPasswordModal = false;
  
  authService = inject(AuthService);
  private auth = inject(Auth);
  private firestore = inject(Firestore);
  private location = inject(Location);
  private router = inject(Router);

  nickname = '';
  formData = {
    name: '',
    lastname: '',
    phone: ''
  };

  goBack() {
    this.location.back();
  }

  async onSubmit(event: Event) {
    event.preventDefault();
    this.loading = true;

    try {
      const user = this.authService.currentUser();
      if (!user) {
        throw new Error('No hay usuario autenticado');
      }

      const userDocRef = doc(this.firestore, 'users', user.id);
      await updateDoc(userDocRef, {
        nickname: this.nickname,
        name: this.formData.name,
        lastname: this.formData.lastname,
        phone: this.formData.phone,
        updatedAt: new Date().toISOString()
      });

      alert('Datos actualizados correctamente');
    } catch (error: any) {
      console.error('Error al actualizar datos:', error);
      alert('Error al actualizar datos: ' + error.message);
    } finally {
      this.loading = false;
    }
  }

  async deleteAccount() {
    if (!confirm('¿Estás seguro de que quieres eliminar tu cuenta? Esta acción no se puede deshacer.')) {
      return;
    }

    try {
      const user = this.authService.currentUser();
      if (!user) {
        throw new Error('No hay usuario autenticado');
      }

      const userDocRef = doc(this.firestore, 'users', user.id);
      await deleteDoc(userDocRef);
      
      const currentUser = this.auth.currentUser;
      if (currentUser) {
        await currentUser.delete();
      }

      alert('Cuenta eliminada correctamente');
      this.router.navigate(['/login']);
    } catch (error: any) {
      console.error('Error al eliminar cuenta:', error);
      alert('Error al eliminar cuenta: ' + error.message);
    }
  }

  isGoogleLinked(): boolean {
    const user = this.auth.currentUser;
    return user?.providerData.some(p => p.providerId === 'google.com') || false;
  }

  isFacebookLinked(): boolean {
    const user = this.auth.currentUser;
    return user?.providerData.some(p => p.providerId === 'facebook.com') || false;
  }

  isPasswordLinked(): boolean {
    const user = this.auth.currentUser;
    return user?.providerData.some(p => p.providerId === 'password') || false;
  }

  async linkGoogle() {
    this.loadingGoogle = true;
    try {
      const provider = new GoogleAuthProvider();
      const user = this.auth.currentUser;
      if (user) {
        await linkWithPopup(user, provider);
        alert('Cuenta de Google vinculada correctamente');
      }
    } catch (error: any) {
      console.error('Error al vincular Google:', error);
      alert('Error al vincular Google: ' + error.message);
    } finally {
      this.loadingGoogle = false;
    }
  }

  async unlinkGoogle() {
    if (!confirm('¿Deseas desvincular tu cuenta de Google?')) {
      return;
    }

    this.loadingUnlinkGoogle = true;
    try {
      const user = this.auth.currentUser;
      if (user) {
        await unlink(user, 'google.com');
        alert('Cuenta de Google desvinculada correctamente');
      }
    } catch (error: any) {
      console.error('Error al desvincular Google:', error);
      alert('Error al desvincular Google: ' + error.message);
    } finally {
      this.loadingUnlinkGoogle = false;
    }
  }

  async linkFacebook() {
    this.loadingFacebook = true;
    try {
      const provider = new FacebookAuthProvider();
      const user = this.auth.currentUser;
      if (user) {
        await linkWithPopup(user, provider);
        alert('Cuenta de Facebook vinculada correctamente');
      }
    } catch (error: any) {
      console.error('Error al vincular Facebook:', error);
      alert('Error al vincular Facebook: ' + error.message);
    } finally {
      this.loadingFacebook = false;
    }
  }

  async unlinkFacebook() {
    if (!confirm('¿Deseas desvincular tu cuenta de Facebook?')) {
      return;
    }

    this.loadingUnlinkFacebook = true;
    try {
      const user = this.auth.currentUser;
      if (user) {
        await unlink(user, 'facebook.com');
        alert('Cuenta de Facebook desvinculada correctamente');
      }
    } catch (error: any) {
      console.error('Error al desvincular Facebook:', error);
      alert('Error al desvincular Facebook: ' + error.message);
    } finally {
      this.loadingUnlinkFacebook = false;
    }
  }

  changePassword() {
    this.showPasswordModal = true;
  }

  closePasswordModal() {
    this.showPasswordModal = false;
  }

  onPasswordChanged() {
    this.showPasswordModal = false;
    alert('Contraseña actualizada correctamente');
  }
}
