import { Routes } from '@angular/router';
import { LoginComponent } from './features/auth/components/login.component';
import { RegisterComponent } from './features/auth/components/register.component';
import { authGuard, adminGuard } from './features/auth/auth.guard';

import { Home } from './features/product/components/home/home';
import { GestionProductos } from './features/admin/components/gestion-productos/gestion-productos';
import { Perfil } from './perfil/perfil';
import { CuentaComponent } from './perfil/cuenta/cuenta.component';
import { PedidosComponent } from './perfil/pedidos/pedidos.component';
import { CheckoutComponent } from './features/order/components/checkout/checkout.component';
import { OrderConfirmationComponent } from './features/order/components/order-confirmation/order-confirmation.component';
import { OrderHistoryComponent } from './features/order/components/order-history/order-history.component';
import { TrackOrderComponent } from './features/order/components/track-order/track-order.component';
import { AdminOrdersComponent } from './features/order/components/admin-orders/admin-orders.component';
import { GestionRestaurantes } from './features/admin/components/gestion-restaurantes/gestion-restaurantes';
import { GestionOfertas } from './features/admin/components/gestion-ofertas/gestion-ofertas';
import { DashboardReportes } from './features/admin/components/dashboard-reportes/dashboard-reportes';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: Home },
  {
    path: 'checkout',
    component: CheckoutComponent,
    canActivate: [authGuard]
  },
  {
    path: 'order-confirmation',
    component: OrderConfirmationComponent,
    canActivate: [authGuard]
  },
  {
    path: 'track-order/:id',
    component: TrackOrderComponent,
    canActivate: [authGuard]
  },
  {
    path: 'gestion-productos',
    component: GestionProductos,
    canActivate: [adminGuard]
  },
  {
    path: 'admin-orders',
    component: AdminOrdersComponent,
    canActivate: [adminGuard]
  },
  {
    path: 'gestion-restaurantes',
    component: GestionRestaurantes,
    canActivate: [adminGuard]
  },
  {
    path: 'gestion-ofertas',
    component: GestionOfertas,
    canActivate: [adminGuard]
  },
  {
    path: 'dashboard-reportes',
    component: DashboardReportes,
    canActivate: [adminGuard]
  },
  {
    path: 'perfil',
    component: Perfil,
    canActivate: [authGuard],
    children: [
      { path: '', redirectTo: 'cuenta', pathMatch: 'full' },
      { path: 'cuenta', component: CuentaComponent },
      { path: 'pedidos', component: PedidosComponent },
      { path: 'puntos', loadComponent: () => import('./perfil/puntos/puntos.component').then(m => m.PuntosComponent) }
    ]
  },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent }
];
