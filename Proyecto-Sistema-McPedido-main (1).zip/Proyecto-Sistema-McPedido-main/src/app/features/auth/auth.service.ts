import { Injectable, signal, computed, inject, Injector, runInInjectionContext } from '@angular/core';
import { Auth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, user, User, updateProfile, GoogleAuthProvider, FacebookAuthProvider, signInWithPopup, linkWithCredential, linkWithPopup, OAuthProvider } from '@angular/fire/auth';
import { Firestore, doc, setDoc, getDoc, updateDoc, onSnapshot } from '@angular/fire/firestore';
import { Router } from '@angular/router';
import { AuthUser } from './auth.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private auth = inject(Auth);
  private firestore = inject(Firestore);
  private router = inject(Router);
  private injector = inject(Injector);

  private userSignal = signal<AuthUser | null>(null);
  private loadingSignal = signal<boolean>(true); // Estado de carga inicial
  private sessionCheckInterval: any = null;

  // Computed para estado de autenticación
  isAuthenticated = computed(() => this.userSignal() !== null);
  currentUser = computed(() => this.userSignal());
  isLoading = computed(() => this.loadingSignal());

  constructor() {
    // Suscribirse a cambios de autenticación
    user(this.auth).subscribe(async (firebaseUser) => {
      if (firebaseUser) {
        // Envolver en contexto de inyección por si acaso
        const userData = await runInInjectionContext(this.injector, () => this.getUserData(firebaseUser.uid));
        this.userSignal.set({
          id: firebaseUser.uid,
          email: firebaseUser.email || '',
          role: userData?.role || 'client',
          displayName: firebaseUser.displayName || userData?.displayName || '',
          points: userData?.points || 0
        });
      } else {
        this.userSignal.set(null);
        if (this.sessionCheckInterval) {
          clearInterval(this.sessionCheckInterval);
          this.sessionCheckInterval = null;
        }
      }
      this.loadingSignal.set(false); // Termina la carga
    });
  }

  // Registro de usuario
  async register(email: string, password: string, name?: string): Promise<AuthUser> {
    try {
      const userCredential = await createUserWithEmailAndPassword(this.auth, email, password);
      const user = userCredential.user;

      // Actualizar perfil con nombre
      if (name) {
        await updateProfile(user, { displayName: name });
      }

      // Generar token de sesión único
      const sessionToken = this.generateSessionToken();

      // Guardar datos adicionales en Firestore
      const userData: AuthUser = {
        id: user.uid,
        email: user.email || email,
        role: 'client',
        displayName: name || ''
      };

      await setDoc(doc(this.firestore, 'users', user.uid), {
        email: userData.email,
        role: userData.role,
        displayName: userData.displayName,
        createdAt: new Date().toISOString(),
        activeSessionToken: sessionToken,
        lastLogin: new Date().toISOString(),
        points: 0
      });

      // Guardar token en localStorage
      localStorage.setItem('sessionToken', sessionToken);

      // Iniciar monitoreo de sesión
      this.startSessionMonitoring(user.uid, sessionToken);

      this.userSignal.set(userData);
      return userData;
    } catch (error: any) {
      throw this.handleAuthError(error);
    }
  }

  // Login de usuario
  async login(email: string, password: string): Promise<AuthUser> {
    try {
      const userCredential = await signInWithEmailAndPassword(this.auth, email, password);
      const user = userCredential.user;

      // Generar token de sesión único
      const sessionToken = this.generateSessionToken();

      // Actualizar el token de sesión en Firestore
      const userDocRef = doc(this.firestore, 'users', user.uid);
      await updateDoc(userDocRef, {
        activeSessionToken: sessionToken,
        lastLogin: new Date().toISOString()
      });

      // Guardar el token en localStorage
      localStorage.setItem('sessionToken', sessionToken);

      const userData = await this.getUserData(user.uid);

      const authUser: AuthUser = {
        id: user.uid,
        email: user.email || email,
        role: userData?.role || 'client',
        displayName: user.displayName || userData?.displayName || ''
      };

      // Iniciar monitoreo de sesión
      this.startSessionMonitoring(user.uid, sessionToken);

      this.userSignal.set(authUser);
      return authUser;
    } catch (error: any) {
      throw this.handleAuthError(error);
    }
  }

  // Login con Google
  async loginWithGoogle(): Promise<AuthUser> {
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({
        prompt: 'select_account'
      });

      const userCredential = await signInWithPopup(this.auth, provider);
      const user = userCredential.user;

      // Generar token de sesión único
      const sessionToken = this.generateSessionToken();

      // Verificar si el usuario ya existe en Firestore
      const userDocRef = doc(this.firestore, 'users', user.uid);
      const userDoc = await getDoc(userDocRef);

      const authUser: AuthUser = {
        id: user.uid,
        email: user.email || '',
        role: 'client',
        displayName: user.displayName || ''
      };

      if (userDoc.exists()) {
        // Usuario existente - actualizar sesión pero preservar displayName existente
        const userData = userDoc.data();
        await updateDoc(userDocRef, {
          email: authUser.email,
          activeSessionToken: sessionToken,
          lastLogin: new Date().toISOString()
          // NO actualizar displayName para preservar el apodo personalizado
        });

        // Obtener el rol y displayName del usuario
        authUser.role = userData?.['role'] || 'client';
        authUser.displayName = userData?.['displayName'] || user.displayName || '';
      } else {
        // Nuevo usuario - crear documento
        await setDoc(userDocRef, {
          email: authUser.email,
          role: authUser.role,
          displayName: authUser.displayName,
          createdAt: new Date().toISOString(),
          activeSessionToken: sessionToken,
          lastLogin: new Date().toISOString(),
          points: 0
        });
      }

      // Guardar el token en localStorage
      localStorage.setItem('sessionToken', sessionToken);

      // Iniciar monitoreo de sesión
      this.startSessionMonitoring(user.uid, sessionToken);

      this.userSignal.set(authUser);
      return authUser;
    } catch (error: any) {
      throw this.handleAuthError(error);
    }
  }

  // Login con Facebook (Estrategia: Entrar con Google -> Vincular Facebook)
  async loginWithFacebook(): Promise<AuthUser> {
    try {
      // 1. Intentamos entrar con Facebook
      const fbProvider = new FacebookAuthProvider();
      fbProvider.addScope('email');
      fbProvider.setCustomParameters({ display: 'popup' });

      const userCredential = await signInWithPopup(this.auth, fbProvider);
      const user = userCredential.user;

      // Login exitoso con Facebook - procesamos normalmente
      const sessionToken = this.generateSessionToken();
      const userDocRef = doc(this.firestore, 'users', user.uid);
      const userDoc = await getDoc(userDocRef);

      const authUser: AuthUser = {
        id: user.uid,
        email: user.email || '',
        role: 'client',
        displayName: user.displayName || ''
      };

      if (userDoc.exists()) {
        // Usuario existente - preservar displayName personalizado
        const userData = userDoc.data();
        await updateDoc(userDocRef, {
          email: authUser.email,
          activeSessionToken: sessionToken,
          lastLogin: new Date().toISOString()
          // NO actualizar displayName para preservar el apodo
        });

        authUser.role = userData?.['role'] || 'client';
        authUser.displayName = userData?.['displayName'] || user.displayName || '';
      } else {
        await setDoc(userDocRef, {
          email: authUser.email,
          role: authUser.role,
          displayName: authUser.displayName,
          createdAt: new Date().toISOString(),
          activeSessionToken: sessionToken,
          lastLogin: new Date().toISOString(),
          points: 0
        });
      }

      localStorage.setItem('sessionToken', sessionToken);
      this.startSessionMonitoring(user.uid, sessionToken);
      this.userSignal.set(authUser);
      return authUser;

    } catch (error: any) {


      // SI OCURRE EL ERROR DE CUENTA DUPLICADA
      if (error.code === 'auth/account-exists-with-different-credential') {

        // A. Guardamos la "llave" de Facebook que fue rechazada
        const pendingCredential = OAuthProvider.credentialFromError(error);
        const email = error.customData?.['email'];

        // B. Log para debugging


        try {
          const googleProvider = new GoogleAuthProvider();
          googleProvider.setCustomParameters({ prompt: 'select_account' });

          // C. PASO CRUCIAL: Primero completamos el login con Google
          const googleResult = await signInWithPopup(this.auth, googleProvider);

          // D. Ahora que ya hay usuario conectado, intentamos vincular Facebook
          if (pendingCredential) {
            try {
              await linkWithCredential(googleResult.user, pendingCredential);

            } catch (linkError) {
              // Si falla la vinculación, NO bloqueamos (el usuario ya entró con Google)

            }
          }

          // E. Procesamos el login con la cuenta de Google
          const user = googleResult.user;
          const sessionToken = this.generateSessionToken();
          const userDocRef = doc(this.firestore, 'users', user.uid);
          const userDoc = await getDoc(userDocRef);

          const authUser: AuthUser = {
            id: user.uid,
            email: user.email || '',
            role: 'client',
            displayName: user.displayName || ''
          };

          if (userDoc.exists()) {
            // Usuario existente - preservar displayName personalizado
            const userData = userDoc.data();
            await updateDoc(userDocRef, {
              email: authUser.email,
              activeSessionToken: sessionToken,
              lastLogin: new Date().toISOString()
              // NO actualizar displayName
            });

            authUser.role = userData?.['role'] || 'client';
            authUser.displayName = userData?.['displayName'] || user.displayName || '';
          }

          localStorage.setItem('sessionToken', sessionToken);
          this.startSessionMonitoring(user.uid, sessionToken);
          this.userSignal.set(authUser);
          return authUser;

        } catch (googleError: any) {
          // Si el usuario cierra la ventana de Google
          throw new Error('Inicio de sesión cancelado.');
        }
      }

      // Otros errores de Facebook
      throw this.handleAuthError(error);
    }
  }

  // Vincular Google desde el perfil (cuando el usuario ya está conectado)
  async linkGoogleAccount(): Promise<void> {
    const currentUser = this.auth.currentUser;

    if (!currentUser) {
      throw new Error('Debes estar conectado para vincular cuentas');
    }

    try {
      const googleProvider = new GoogleAuthProvider();
      googleProvider.setCustomParameters({
        prompt: 'select_account'
      });

      // Vinculamos usando popup (más fácil y estable)
      await linkWithPopup(currentUser, googleProvider);



    } catch (error: any) {
      if (error.code === 'auth/provider-already-linked') {
        throw new Error('Ya tienes Google vinculado a esta cuenta');
      } else if (error.code === 'auth/credential-already-in-use') {
        throw new Error('Esta cuenta de Google ya está vinculada a otro usuario');
      }
      throw this.handleAuthError(error);
    }
  }

  // Vincular Facebook desde el perfil (cuando el usuario ya está conectado)
  async linkFacebookAccount(): Promise<void> {
    const currentUser = this.auth.currentUser;

    if (!currentUser) {
      throw new Error('Debes estar conectado para vincular cuentas');
    }

    try {
      const fbProvider = new FacebookAuthProvider();
      fbProvider.addScope('email');
      fbProvider.setCustomParameters({ display: 'popup' });

      // Vinculamos usando popup (más fácil y estable)
      await linkWithPopup(currentUser, fbProvider);



    } catch (error: any) {
      if (error.code === 'auth/provider-already-linked') {
        throw new Error('Ya tienes Facebook vinculado a esta cuenta');
      } else if (error.code === 'auth/credential-already-in-use') {
        throw new Error('Esta cuenta de Facebook ya está vinculada a otro usuario');
      }
      throw this.handleAuthError(error);
    }
  }

  // Cerrar sesión
  async logout(): Promise<void> {
    try {
      const user = this.auth.currentUser;

      // 1. Intentamos actualizar la DB (si el perfil existe)
      if (user) {
        const userRef = doc(this.firestore, 'users', user.uid);
        try {
          await updateDoc(userRef, {
            activeSessionToken: null,
            lastLogout: new Date().toISOString(),
            isOnline: false
          });
        } catch (dbError) {
          // Si falla la DB (porque no existe el perfil), solo lo logueamos y seguimos

        }
      }

      // Limpiar localStorage
      localStorage.removeItem('sessionToken');

      // Limpiar intervalo de monitoreo
      if (this.sessionCheckInterval) {
        clearInterval(this.sessionCheckInterval);
        this.sessionCheckInterval = null;
      }

      // 2. Cerramos sesión (Esto se ejecuta SÍ o SÍ)
      await signOut(this.auth);

      this.userSignal.set(null);
    } catch (error: any) {

      throw new Error('Error al cerrar sesión');
    }
  }

  isAdmin(): boolean {
    const user = this.currentUser();
    return user?.role === 'admin';
  }

  // Obtener datos de usuario desde Firestore
  private async getUserData(uid: string): Promise<any> {
    try {
      const userDoc = await getDoc(doc(this.firestore, 'users', uid));
      return userDoc.exists() ? userDoc.data() : null;
    } catch (error) {
      return null;
    }
  }

  // Manejo de errores de Firebase Auth
  private handleAuthError(error: any): Error {
    let message = 'Error de autenticación';

    switch (error.code) {
      case 'auth/email-already-in-use':
        message = 'Este correo ya está registrado';
        break;
      case 'auth/invalid-email':
        message = 'Correo electrónico inválido';
        break;
      case 'auth/operation-not-allowed':
        message = 'Operación no permitida';
        break;
      case 'auth/weak-password':
        message = 'La contraseña es muy débil (mínimo 6 caracteres)';
        break;
      case 'auth/user-disabled':
        message = 'Usuario deshabilitado';
        break;
      case 'auth/user-not-found':
        message = 'Usuario no encontrado';
        break;
      case 'auth/wrong-password':
        message = 'Contraseña incorrecta';
        break;
      case 'auth/invalid-credential':
        message = 'Credenciales inválidas';
        break;
      default:
        message = error.message || 'Error desconocido';
    }

    return new Error(message);
  }

  // Generar un token único para la sesión
  private generateSessionToken(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  // Monitorear si la sesión sigue siendo válida
  private startSessionMonitoring(userId: string, sessionToken: string): void {
    // Limpiar intervalo anterior si existe
    if (this.sessionCheckInterval) {
      clearInterval(this.sessionCheckInterval);
    }

    this.sessionCheckInterval = setInterval(async () => {
      // Envolver llamadas a Firestore en contexto de inyección
      runInInjectionContext(this.injector, async () => {
        try {
          const userDocRef = doc(this.firestore, 'users', userId);
          const userDoc = await getDoc(userDocRef);

          if (userDoc.exists()) {
            const userData = userDoc.data();
            const activeToken = userData['activeSessionToken'];

            // Si el token cambió, significa que alguien más inició sesión
            if (activeToken && activeToken !== sessionToken) {


              // Limpiar el intervalo
              if (this.sessionCheckInterval) {
                clearInterval(this.sessionCheckInterval);
                this.sessionCheckInterval = null;
              }

              // Cerrar sesión local
              localStorage.removeItem('sessionToken');
              await signOut(this.auth);
              this.router.navigate(['/']);
            }
          }
        } catch (error) {

        }
      });
    }, 5000); // Verificar cada 5 segundos
  }

  // Método para actualizar el displayName en el signal
  updateDisplayName(newDisplayName: string): void {
    const currentUserData = this.userSignal();
    if (currentUserData) {
      this.userSignal.set({
        ...currentUserData,
        displayName: newDisplayName
      });
    }
  }

  async addPoints(userId: string, points: number): Promise<void> {
    const userRef = doc(this.firestore, 'users', userId);
    const userDoc = await getDoc(userRef);

    if (userDoc.exists()) {
      const currentPoints = userDoc.data()['points'] || 0;
      const newPoints = currentPoints + points;

      await updateDoc(userRef, {
        points: newPoints
      });

      // Update local signal if it's the current user
      const currentUser = this.userSignal();
      if (currentUser && currentUser.id === userId) {
        this.userSignal.set({
          ...currentUser,
          points: newPoints
        });
      }
    }
  }

  // Refrescar datos del usuario actual
  async refreshUserData(): Promise<void> {
    const currentUser = this.userSignal();
    if (currentUser) {
      const userData = await this.getUserData(currentUser.id);
      if (userData) {
        this.userSignal.set({
          ...currentUser,
          role: userData.role || currentUser.role,
          displayName: userData.displayName || currentUser.displayName,
          points: userData.points || 0
        });
      }
    }
  }
}
