import { Component, output } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../auth.service';

@Component({
  standalone: true,
  selector: 'app-login',
  imports: [ReactiveFormsModule, RouterModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loading = false;
  error: string | null = null;
  form: any;
  openRegisterRequested = output<void>();
  closeRequested = output<void>();

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {
    this.form = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  onClose() {
    this.closeRequested.emit();
  }

  onRegisterClick() {
    this.openRegisterRequested.emit();
  }

  async submit() {
    if (this.form.invalid || this.loading) {
      this.form.markAllAsTouched?.();
      return;
    }
    this.loading = true;
    this.error = null;
    const { email, password } = this.form.value as any;
    try {
      const user = await this.auth.login(email, password);
      // Redirigir según rol
      if (user?.role === 'admin') {
        await this.router.navigate(['/admin']);
      } else {
        await this.router.navigate(['/']);
      }
      // Cerrar modal
      this.closeRequested.emit();
    } catch (err: any) {
      this.error = err?.message || 'Error al iniciar sesión';
    } finally {
      this.loading = false;
    }
  }

  async loginWithGoogle() {
    this.loading = true;
    this.error = null;
    try {
      const user = await this.auth.loginWithGoogle();
      // Redirigir según rol
      if (user?.role === 'admin') {
        await this.router.navigate(['/admin']);
      } else {
        await this.router.navigate(['/']);
      }
      // Cerrar modal
      this.closeRequested.emit();
    } catch (err: any) {
      this.error = err?.message || 'Error al iniciar sesión con Google';
    } finally {
      this.loading = false;
    }
  }

  async loginWithFacebook() {
    this.loading = true;
    this.error = null;
    try {
      const user = await this.auth.loginWithFacebook();
      // Redirigir según rol
      if (user?.role === 'admin') {
        await this.router.navigate(['/admin']);
      } else {
        await this.router.navigate(['/']);
      }
      // Cerrar modal
      this.closeRequested.emit();
    } catch (err: any) {
      this.error = err?.message || 'Error al iniciar sesión con Facebook';
    } finally {
      this.loading = false;
    }
  }
}
