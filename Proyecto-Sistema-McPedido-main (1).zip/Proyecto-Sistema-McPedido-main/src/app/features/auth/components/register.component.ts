import { Component, output } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../auth.service';

@Component({
  standalone: true,
  selector: 'app-register',
  imports: [ReactiveFormsModule, RouterModule, CommonModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  loading = false;
  error: string | null = null;
  form: any;
  backToLoginRequested = output<void>();
  closeRequested = output<void>();

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {
    this.form = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirm: ['', [Validators.required]]
    });
  }

  onClose() {
    this.closeRequested.emit();
  }

  onBackToLoginClick() {
    this.backToLoginRequested.emit();
  }

  async register() {
    if (this.form.invalid || this.loading) {
      this.form.markAllAsTouched?.();
      return;
    }
    const { name, email, password, confirm } = this.form.value as any;
    if (password !== confirm) {
      this.error = 'Las contraseñas no coinciden';
      return;
    }
    this.loading = true;
    this.error = null;
    try {
      const user = await this.auth.register(email, password, name);
      // Redirigir al home tras registro exitoso
      await this.router.navigate(['/']);
      this.closeRequested.emit();
    } catch (err: any) {
      this.error = err?.message || 'Error al registrarse';
    } finally {
      this.loading = false;
    }
  }

  async loginWithGoogle() {
    this.loading = true;
    this.error = null;
    try {
      const user = await this.auth.loginWithGoogle();
      // Redirigir según rol
      if (user?.role === 'admin') {
        await this.router.navigate(['/admin']);
      } else {
        await this.router.navigate(['/']);
      }
      // Cerrar modal
      this.closeRequested.emit();
    } catch (err: any) {
      this.error = err?.message || 'Error al iniciar sesión con Google';
    } finally {
      this.loading = false;
    }
  }
}
