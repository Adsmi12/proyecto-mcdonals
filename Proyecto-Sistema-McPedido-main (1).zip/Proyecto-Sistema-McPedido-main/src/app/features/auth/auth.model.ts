export interface AuthUser {
  id: string;
  email: string;
  role: 'admin' | 'client' | string;
  displayName?: string;
  points?: number;
}
