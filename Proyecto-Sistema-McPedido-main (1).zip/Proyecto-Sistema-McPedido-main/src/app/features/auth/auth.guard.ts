import { inject } from '@angular/core';
import { Router, CanActivateFn } from '@angular/router';
import { AuthService } from './auth.service';
import { map, take, filter } from 'rxjs/operators';

export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // Esperar a que termine de cargar antes de verificar autenticación
  return new Promise<boolean>((resolve) => {
    const checkAuth = () => {
      if (!authService.isLoading()) {
        if (authService.isAuthenticated()) {
          resolve(true);
        } else {
          router.navigate(['/']);
          resolve(false);
        }
      } else {
        // Volver a verificar después de un breve delay
        setTimeout(checkAuth, 50);
      }
    };
    checkAuth();
  });
};

export const adminGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // Esperar a que termine de cargar antes de verificar rol
  return new Promise<boolean>((resolve) => {
    const checkAdmin = () => {
      if (!authService.isLoading()) {
        const user = authService.currentUser();
        if (user && user.role === 'admin') {
          resolve(true);
        } else {
          router.navigate(['/']);
          resolve(false);
        }
      } else {
        // Volver a verificar después de un breve delay
        setTimeout(checkAdmin, 50);
      }
    };
    checkAdmin();
  });
};
