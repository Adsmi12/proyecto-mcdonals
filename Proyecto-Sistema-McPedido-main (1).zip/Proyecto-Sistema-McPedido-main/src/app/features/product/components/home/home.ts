import { Component, signal, computed, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CartService } from '../../../../services/cart.service';
import { ToastService } from '../../../../services/toast.service';
import { FirebaseService } from '../../../../services/firebase';
import { Producto } from '../../../../interfaces/producto.interface';
import { Offer } from '../../../../interfaces/offer.interface';
import { OfferService } from '../../../../services/offer.service';
import { RestaurantService } from '../../../../services/restaurant.service';
import { Restaurant, RestaurantProduct } from '../../../../interfaces/restaurant.interface';
import { ProductCustomizationComponent } from '../product-customization/product-customization.component';
import { ChickenCustomizationComponent } from '../chicken-customization/chicken-customization.component';
import { Observable, combineLatest, of } from 'rxjs';
import { map, shareReplay, startWith, tap } from 'rxjs/operators';
import { toObservable } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-home',
  imports: [CommonModule, FormsModule, ProductCustomizationComponent, ChickenCustomizationComponent],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {
  categoriaSeleccionada: string = 'Todas';
  searchQuery = signal<string>('');
  isCustomizationModalOpen = signal(false);
  isChickenCustomizationModalOpen = signal(false);
  selectedProduct = signal<Producto | null>(null);
  selectedRestaurantId = signal<string | null>(null); // Restaurante seleccionado

  productos$: Observable<Producto[]>;
  productosFiltrados$: Observable<any[]>; // Acepta productos y combos
  combos$: Observable<Offer[]>; // Combos activos
  restaurants$: Observable<Restaurant[]>; // Restaurantes disponibles

  categorias: string[] = [
    'Todas',
    'Hamburguesas',
    'Para Acompañar',
    'Pollo y McNuggets',
    'Bebidas'
  ];

  constructor(
    private cartService: CartService,
    private firebaseService: FirebaseService,
    private toastService: ToastService,
    private offerService: OfferService,
    private restaurantService: RestaurantService
  ) {
    // Cargar productos con cache
    this.productos$ = this.firebaseService.getProductos().pipe(
      shareReplay(1)
    );

    // Cargar restaurantes
    this.restaurants$ = this.restaurantService.getRestaurants().pipe(
      shareReplay(1)
    );

    // Cargar combos activos filtrados por restaurante
    this.combos$ = combineLatest([
      this.offerService.getActiveCombos(),
      toObservable(this.selectedRestaurantId)
    ]).pipe(

      map(([combos, selectedRestId]) => {
        return combos.filter(combo => {
          // Filtrar por restaurante si hay uno seleccionado
          if (selectedRestId) {
            return !combo.restaurantId || combo.restaurantId === selectedRestId;
          }
          // Si no hay restaurante, mostrar combos globales
          return !combo.restaurantId;
        });
      }),
      shareReplay(1)
    );

    // Cargar ofertas activas (descuentos normales) filtradas por restaurante
    const activeOffers$ = combineLatest([
      this.offerService.getActiveOffers(),
      toObservable(this.selectedRestaurantId)
    ]).pipe(
      map(([offers, selectedRestId]) => {
        return offers.filter(o => {
          // No es combo
          if (o.type === 'combo') return false;

          // Filtrar por restaurante si hay uno seleccionado
          if (selectedRestId) {
            // La oferta debe ser global (sin restaurantId) o específica del restaurante seleccionado
            return !o.restaurantId || o.restaurantId === selectedRestId;
          }

          // Si no hay restaurante seleccionado, mostrar ofertas globales
          return !o.restaurantId;
        });
      }),
      shareReplay(1)
    );

    // Combinar productos, ofertas normales y combos
    this.productosFiltrados$ = combineLatest([
      this.productos$,
      activeOffers$,
      this.combos$,
      toObservable(this.selectedRestaurantId),
      this.restaurants$
    ]).pipe(
      map(([productos, offers, combos, selectedRestId, restaurants]) => {
        // Filtrar productos por restaurante (solo mostrar los que tienen stock en el restaurante seleccionado)
        let productosFiltrados = productos;

        if (selectedRestId) {
          const selectedRestaurant = restaurants.find(r => r.id === selectedRestId);
          if (selectedRestaurant) {
            productosFiltrados = productos.filter(producto => {
              // Buscar el producto en la lista de productos del restaurante
              const restaurantProduct = selectedRestaurant.products?.find((p: RestaurantProduct) => p.productId === producto.id);

              // Verificar si existe, tiene stock y está disponible
              return restaurantProduct && restaurantProduct.stock > 0 && restaurantProduct.available !== false;
            });

            // Opcional: Actualizar precio con precio local si existe
            // Esto requeriría clonar el objeto producto para no mutar el original en cache
            productosFiltrados = productosFiltrados.map(producto => {
              const restaurantProduct = selectedRestaurant.products?.find((p: RestaurantProduct) => p.productId === producto.id);
              if (restaurantProduct && restaurantProduct.localPrice) {
                return { ...producto, precio: restaurantProduct.localPrice };
              }
              return producto;
            });
          }
        }

        // Aplicar ofertas normales a productos filtrados
        const productosConOfertas = productosFiltrados.map(producto => {
          const offer = offers.find(o => {
            if (o.applicableTo === 'all') return true;
            if (o.applicableTo === 'category' && o.categoryId === producto.categoria) return true;
            if (o.applicableTo === 'product' && o.productIds?.includes(producto.id || '')) return true;
            return false;
          });

          if (offer) {
            const discountedPrice = this.offerService.applyOffer(offer, producto.precio);
            return {
              ...producto,
              hasOffer: true,
              discountedPrice,
              originalPrice: producto.precio,
              offerType: offer.type,
              offerValue: offer.value
            };
          }
          return producto;
        });

        // Convertir combos a formato de producto
        const combosComoProductos = combos.map((combo: Offer) => {
          let comboProducts = combo.comboProducts;
          if (!comboProducts && combo.productIds && combo.productIds.length > 0) {
            comboProducts = combo.productIds.map(productId => ({
              productId: productId,
              productName: '',
              quantity: 1
            }));
          }

          return {
            id: combo.id || '',
            nombre: combo.name,
            precio: combo.comboPrice || combo.value,
            fotoUrl: combo.imageUrl || '',
            categoria: 'Combos',
            descripcion: combo.description,
            disponible: combo.active,
            isCombo: true,
            comboProducts: comboProducts,
            ingredientes: []
          };
        });

        // Combinar productos con ofertas y combos
        const todosLosItems: any[] = [...productosConOfertas, ...combosComoProductos];

        // Ordenar: Combos > Descuento % > Descuento fijo > Sin oferta
        const itemsOrdenados = todosLosItems.sort((a, b) => {
          // Prioridad 1: Combos primero
          if (a.isCombo && !b.isCombo) return -1;
          if (!a.isCombo && b.isCombo) return 1;

          // Prioridad 2: Ofertas de porcentaje
          if (a.offerType === 'percentage' && b.offerType !== 'percentage') return -1;
          if (a.offerType !== 'percentage' && b.offerType === 'percentage') return 1;

          // Prioridad 3: Ofertas fijas
          if (a.offerType === 'fixed' && !b.offerType) return -1;
          if (!a.offerType && b.offerType === 'fixed') return 1;

          // Si son del mismo tipo, mantener orden original
          return 0;
        });

        return this.filtrarProductos(itemsOrdenados);
      }),
      shareReplay(1)
    );

    // Effect removido - el filtrado es reactivo via filtrarProductos()
  }

  private filtrarProductos(productos: Producto[]): Producto[] {
    let filtrados = productos;

    // Filtrar por categoría
    if (this.categoriaSeleccionada !== 'Todas') {
      filtrados = filtrados.filter(p => p.categoria === this.categoriaSeleccionada);
    }

    // Filtrar por búsqueda
    const query = this.searchQuery().toLowerCase().trim();
    if (query) {
      filtrados = filtrados.filter(p =>
        p.nombre.toLowerCase().includes(query) ||
        p.descripcion.toLowerCase().includes(query)
      );
    }

    return filtrados;
  }

  cambiarCategoria(categoria: string) {
    this.categoriaSeleccionada = categoria;
  }

  // Helper para obtener precio final (con oferta si aplica)
  getPrecioFinal(producto: any): number {
    return producto.hasOffer && producto.discountedPrice
      ? producto.discountedPrice
      : producto.precio;
  }

  agregarProducto(producto: any) {
    // Si es un combo, agregarlo directamente al carrito
    if (producto.isCombo) {
      this.cartService.addComboToCart({
        id: producto.id,
        nombre: producto.nombre,
        precio: producto.precio,
        imagen: producto.fotoUrl || '',
        comboProducts: producto.comboProducts || []
      });
      this.toastService.show(`El combo ${producto.nombre} se agregó al carrito`);
      return;
    }

    // Hamburguesas usan modal de hamburguesas
    if (producto.categoria === 'Hamburguesas') {
      this.abrirPersonalizacion(producto);
    }
    // McPollo y McPollo Italiano usan modal de pollo
    else if (producto.nombre === 'McPollo' || producto.nombre === 'McPollo italiano') {
      this.abrirPersonalizacionPollo(producto);
    }
    // Otros productos se agregan directamente al carrito
    else {
      // Usar precio con descuento si tiene oferta
      const precioFinal = producto.hasOffer && producto.discountedPrice
        ? producto.discountedPrice
        : producto.precio;

      this.cartService.addToCart({
        id: producto.id || '',
        nombre: producto.nombre,
        precio: precioFinal,
        imagen: producto.fotoUrl || ''
      });
      this.toastService.show(`El producto ${producto.nombre} se agregó al carrito`);
    }
  }

  abrirPersonalizacion(producto: Producto) {
    this.selectedProduct.set(producto);
    this.isCustomizationModalOpen.set(true);
  }

  cerrarPersonalizacion() {
    this.isCustomizationModalOpen.set(false);
    this.selectedProduct.set(null);
  }

  abrirPersonalizacionPollo(producto: Producto) {
    this.selectedProduct.set(producto);
    this.isChickenCustomizationModalOpen.set(true);
  }

  cerrarPersonalizacionPollo() {
    this.isChickenCustomizationModalOpen.set(false);
    this.selectedProduct.set(null);
  }

  onPolloPersonalizado(data: any) {
    this.cartService.addToCart({
      id: data.producto.id || '',
      nombre: data.producto.nombre,
      precio: data.precioTotal,
      imagen: data.producto.fotoUrl || '',
      cantidad: data.cantidad,
      ingredientesRemovidos: data.ingredientesRemovidos,
      extrasAgregados: data.extrasAgregados,
      precioUnitario: data.precioTotal / data.cantidad
    });
    this.toastService.show(`El producto ${data.producto.nombre} se agregó al carrito`);
    this.cerrarPersonalizacionPollo();
  }

  onProductoPersonalizado(data: any) {
    this.cartService.addToCart({
      id: data.producto.id || '',
      nombre: data.producto.nombre,
      precio: data.precioTotal,
      imagen: data.producto.fotoUrl || '',
      cantidad: data.cantidad,
      ingredientesRemovidos: data.ingredientesRemovidos,
      extrasAgregados: data.extrasAgregados,
      precioUnitario: data.precioTotal / data.cantidad
    });
    this.toastService.show(`El producto ${data.producto.nombre} se agregó al carrito`);
    this.cerrarPersonalizacion();
  }

  // Método stub para cambiar restaurante (TODO: implementar completamente)
  cambiarRestaurante(restaurantId: string) {
    this.selectedRestaurantId.set(restaurantId || null);
  }
}
