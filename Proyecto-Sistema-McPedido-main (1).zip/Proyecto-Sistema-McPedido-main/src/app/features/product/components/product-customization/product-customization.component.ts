import { Component, input, output, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Producto } from '../../../../interfaces/producto.interface';

interface Ingrediente {
  id: string;
  nombre: string;
  precio: number;
  incluido: boolean; // Si viene por defecto en el producto
}

interface Extra {
  id: string;
  nombre: string;
  precio: number;
}


@Component({
  selector: 'app-product-customization',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-customization.component.html',
  styleUrl: './product-customization.component.css'
})
export class ProductCustomizationComponent {
  isOpen = input<boolean>(false);
  product = input<Producto | null>(null);
  basePrice = input<number>(0); // Precio base (puede ser con descuento)

  closeModal = output<void>();
  addToCart = output<{
    producto: Producto;
    ingredientesRemovidos: string[];
    extrasAgregados: { id: string; nombre: string; precio: number }[];
    precioTotal: number;
    cantidad: number;
  }>();

  cantidad = signal(1);

  // Ingredientes que vienen en el producto
  ingredientes = signal<Ingrediente[]>([
    { id: 'lechuga', nombre: 'Lechuga', precio: 0, incluido: true },
    { id: 'tomate', nombre: 'Tomate', precio: 0, incluido: true },
    { id: 'cebolla', nombre: 'Cebolla', precio: 0, incluido: true },
    { id: 'pepinillos', nombre: 'Pepinillos', precio: 0, incluido: true },
    { id: 'queso', nombre: 'Queso', precio: 0, incluido: true },
  ]);

  // Extras disponibles para agregar
  extras = signal<Extra[]>([
    { id: 'queso-extra', nombre: 'Queso Extra', precio: 500 },
    { id: 'tocino', nombre: 'Tocino', precio: 800 },
    { id: 'huevo', nombre: 'Huevo', precio: 600 },
    { id: 'doble-carne', nombre: 'Doble Carne', precio: 1500 },
    { id: 'salsa-especial', nombre: 'Salsa Especial', precio: 300 },
  ]);

  // Estado de ingredientes y extras seleccionados
  ingredientesSeleccionados = signal<Set<string>>(new Set(['lechuga', 'tomate', 'cebolla', 'pepinillos', 'queso']));
  extrasSeleccionados = signal<Set<string>>(new Set());

  // Precio total calculado
  precioTotal = computed(() => {
    // Usar basePrice si está definido (precio con oferta), sino precio original
    const precioBase = this.basePrice() || this.product()?.precio || 0;
    const precioExtras = Array.from(this.extrasSeleccionados()).reduce((total, extraId) => {
      const extra = this.extras().find(e => e.id === extraId);
      return total + (extra?.precio || 0);
    }, 0);
    return (precioBase + precioExtras) * this.cantidad();
  });

  onCloseModal() {
    this.closeModal.emit();
    this.resetCustomization();
  }

  toggleIngrediente(ingredienteId: string) {
    const current = new Set(this.ingredientesSeleccionados());
    if (current.has(ingredienteId)) {
      current.delete(ingredienteId);
    } else {
      current.add(ingredienteId);
    }
    this.ingredientesSeleccionados.set(current);
  }

  toggleExtra(extraId: string) {
    const current = new Set(this.extrasSeleccionados());
    if (current.has(extraId)) {
      current.delete(extraId);
    } else {
      current.add(extraId);
    }
    this.extrasSeleccionados.set(current);
  }

  incrementarCantidad() {
    this.cantidad.update(c => c + 1);
  }

  decrementarCantidad() {
    if (this.cantidad() > 1) {
      this.cantidad.update(c => c - 1);
    }
  }

  agregarAlCarrito() {
    const producto = this.product();
    if (!producto) return;

    // Ingredientes removidos
    const todosIngredientes = this.ingredientes().map(i => i.id);
    const ingredientesRemovidos = todosIngredientes.filter(
      id => !this.ingredientesSeleccionados().has(id)
    );

    // Extras agregados
    const extrasAgregados = Array.from(this.extrasSeleccionados()).map(extraId => {
      const extra = this.extras().find(e => e.id === extraId);
      return {
        id: extra!.id,
        nombre: extra!.nombre,
        precio: extra!.precio
      };
    });

    this.addToCart.emit({
      producto,
      ingredientesRemovidos,
      extrasAgregados,
      precioTotal: this.precioTotal(),
      cantidad: this.cantidad()
    });

    this.onCloseModal();
  }

  private resetCustomization() {
    this.cantidad.set(1);
    this.ingredientesSeleccionados.set(new Set(['lechuga', 'tomate', 'cebolla', 'pepinillos', 'queso']));
    this.extrasSeleccionados.set(new Set());
  }
}
