import { Component, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CartService } from '../../../../services/cart.service';
import { AuthService } from '../../../auth/auth.service';
import { ToastService } from '../../../../services/toast.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent {
  private router = inject(Router);
  private authService = inject(AuthService);
  private toastService = inject(ToastService);
  isOpen = signal(false);

  constructor(public cartService: CartService) {}

  getExtrasNames(extras: { id: string; nombre: string; precio: number }[]): string {
    return extras.map(e => e.nombre).join(', ');
  }

  toggleCart() {
    this.isOpen.update(value => !value);
  }

  closeCart() {
    this.isOpen.set(false);
  }

  increaseQuantity(index: number, currentQuantity: number) {
    this.cartService.updateQuantity(index, currentQuantity + 1);
  }

  decreaseQuantity(index: number, currentQuantity: number) {
    this.cartService.updateQuantity(index, currentQuantity - 1);
  }

  removeItem(index: number) {
    this.cartService.removeFromCart(index);
  }

  goToCheckout() {
    this.closeCart();
    // Verificar si el usuario está autenticado
    if (!this.authService.isAuthenticated()) {
      this.toastService.show('Tienes que estar registrado para continuar', 'error');
      return;
    }
    
    this.router.navigate(['/checkout']);
  }
}
