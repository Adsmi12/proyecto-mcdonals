import { Component, Input, Output, EventEmitter, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Producto } from '../../../../interfaces/producto.interface';

interface Ingrediente {
  id: string;
  nombre: string;
  precio: number;
  incluido: boolean;
}

interface Extra {
  id: string;
  nombre: string;
  precio: number;
}


@Component({
  selector: 'app-chicken-customization',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './chicken-customization.component.html',
  styleUrl: './chicken-customization.component.css'
})
export class ChickenCustomizationComponent {
  @Input() isOpen: boolean = false;
  @Input() product: Producto | null = null;
  @Input() basePrice: number = 0; // Precio base (puede ser con descuento)
  @Output() closeModal = new EventEmitter<void>();
  @Output() addToCart = new EventEmitter<any>();

  cantidad = signal(1);

  ingredientes = signal<Ingrediente[]>([
    { id: 'lechuga', nombre: 'Lechuga', precio: 0, incluido: true },
    { id: 'tomate', nombre: 'Tomate', precio: 0, incluido: true },
    { id: 'cebolla', nombre: 'Cebolla', precio: 0, incluido: false },
    { id: 'pepinillos', nombre: 'Pepinillos', precio: 0, incluido: false },
    { id: 'mayonesa', nombre: 'Mayonesa', precio: 0, incluido: true }
  ]);

  extras = signal<Extra[]>([
    { id: 'pollo-extra', nombre: 'Pollo extra', precio: 1500 },
    { id: 'queso', nombre: 'Queso', precio: 500 },
    { id: 'tocino', nombre: 'Tocino', precio: 800 },
    { id: 'huevo', nombre: 'Huevo', precio: 600 },
    { id: 'palta', nombre: 'Palta', precio: 700 }
  ]);

  ingredientesSeleccionados = signal<Set<string>>(new Set(['lechuga', 'tomate', 'mayonesa']));
  extrasSeleccionados = signal<Set<string>>(new Set());

  precioTotal = computed(() => {
    if (!this.product) return 0;

    // Usar basePrice si está definido (precio con oferta), sino precio original
    const precioBase = this.basePrice || this.product.precio;
    const precioExtras = this.extras()
      .filter(extra => this.extrasSeleccionados().has(extra.id))
      .reduce((sum, extra) => sum + extra.precio, 0);

    return (precioBase + precioExtras) * this.cantidad();
  });

  toggleIngrediente(id: string) {
    const selected = this.ingredientesSeleccionados();
    const newSet = new Set(selected);

    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }

    this.ingredientesSeleccionados.set(newSet);
  }

  toggleExtra(id: string) {
    const selected = this.extrasSeleccionados();
    const newSet = new Set(selected);

    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }

    this.extrasSeleccionados.set(newSet);
  }

  incrementarCantidad() {
    this.cantidad.update(c => c + 1);
  }

  decrementarCantidad() {
    if (this.cantidad() > 1) {
      this.cantidad.update(c => c - 1);
    }
  }

  agregarAlCarrito() {
    if (!this.product) return;

    const todosIngredientes = this.ingredientes();
    const ingredientesRemovidos = todosIngredientes
      .filter(ing => ing.incluido && !this.ingredientesSeleccionados().has(ing.id))
      .map(ing => ing.nombre);

    const extrasAgregados = this.extras()
      .filter(extra => this.extrasSeleccionados().has(extra.id))
      .map(extra => ({ id: extra.id, nombre: extra.nombre, precio: extra.precio }));

    this.addToCart.emit({
      producto: this.product,
      ingredientesRemovidos,
      extrasAgregados,
      precioTotal: this.precioTotal(),
      cantidad: this.cantidad()
    });

    this.resetCustomization();
  }

  cerrar() {
    this.resetCustomization();
    this.closeModal.emit();
  }

  private resetCustomization() {
    this.cantidad.set(1);
    this.ingredientesSeleccionados.set(new Set(['lechuga', 'tomate', 'mayonesa']));
    this.extrasSeleccionados.set(new Set());
  }
}
