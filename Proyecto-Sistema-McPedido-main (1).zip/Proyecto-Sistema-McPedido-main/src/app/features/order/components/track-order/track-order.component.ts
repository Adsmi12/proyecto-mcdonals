import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { OrderService, Order } from '../../order.service';
import { interval } from 'rxjs';

@Component({
  selector: 'app-track-order',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="track-container">
      <div class="track-card" *ngIf="order()">
        <div class="header">
          <button class="btn-back" (click)="goBack()">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M19 12H5M5 12L12 19M5 12L12 5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
            Volver
          </button>
          <h1>Rastreo de Pedido</h1>
          <div class="order-id">#{{ getOrderNumber() }}</div>
        </div>

        <div class="status-timeline">
          <div class="timeline-item" [class.active]="isStatusActive('pendiente')" [class.completed]="isStatusCompleted('pendiente')">
            <div class="timeline-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/>
                <path d="M12 6v6l4 2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
              </svg>
            </div>
            <div class="timeline-content">
              <h3>Pedido Recibido</h3>
              <p>Tu pedido ha sido recibido</p>
            </div>
          </div>

          <div class="timeline-line" [class.completed]="isStatusCompleted('confirmado')"></div>

          <div class="timeline-item" [class.active]="isStatusActive('confirmado')" [class.completed]="isStatusCompleted('confirmado')">
            <div class="timeline-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/>
              </svg>
            </div>
            <div class="timeline-content">
              <h3>Confirmado</h3>
              <p>Pedido confirmado por el restaurante</p>
            </div>
          </div>

          <div class="timeline-line" [class.completed]="isStatusCompleted('preparando')"></div>

          <div class="timeline-item" [class.active]="isStatusActive('preparando')" [class.completed]="isStatusCompleted('preparando')">
            <div class="timeline-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M12 2v7m0 0l3-3m-3 3L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                <rect x="4" y="11" width="16" height="11" rx="2" stroke="currentColor" stroke-width="2"/>
              </svg>
            </div>
            <div class="timeline-content">
              <h3>En Preparación</h3>
              <p>Estamos preparando tu pedido</p>
            </div>
          </div>

          <div class="timeline-line" [class.completed]="isStatusCompleted('en-camino')"></div>

          <div class="timeline-item" [class.active]="isStatusActive('en-camino')" [class.completed]="isStatusCompleted('en-camino')">
            <div class="timeline-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M9 17a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm10 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0z" stroke="currentColor" stroke-width="2"/>
                <path d="M13 17h-3m-7-4h14v4M3 13l2-9h10l2 9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
              </svg>
            </div>
            <div class="timeline-content">
              <h3>En Camino</h3>
              <p>Tu pedido está en camino</p>
            </div>
          </div>

          <div class="timeline-line" [class.completed]="isStatusCompleted('entregado')"></div>

          <div class="timeline-item" [class.active]="isStatusActive('entregado')" [class.completed]="isStatusCompleted('entregado')">
            <div class="timeline-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M20 6L9 17l-5-5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
              </svg>
            </div>
            <div class="timeline-content">
              <h3>Entregado</h3>
              <p>¡Tu pedido ha sido entregado!</p>
            </div>
          </div>
        </div>

        <div class="order-info">
          <div class="info-card">
            <h3>Información de Entrega</h3>
            <div class="info-row">
              <span class="label">Tipo:</span>
              <span class="value">{{order()!.delivery.type === 'pickup' ? 'Retiro en local' : 'Delivery'}}</span>
            </div>
            <div class="info-row">
              <span class="label">Ubicación:</span>
              <span class="value">{{order()!.delivery.location}}</span>
            </div>
            <div class="info-row" *ngIf="order()!.estimatedTime">
              <span class="label">Tiempo estimado:</span>
              <span class="value estimated">{{formatEstimatedTime()}}</span>
            </div>
            <div class="info-row points-row" *ngIf="order()!.pointsEarned">
              <span class="label">Puntos ganados:</span>
              <span class="value points">+{{order()!.pointsEarned}} pts</span>
            </div>
          </div>

          <div class="info-card">
            <h3>Resumen del Pedido</h3>
            <div class="items-summary">
              <div class="summary-item" *ngFor="let item of order()!.items">
                <span>{{item.cantidad}}x {{item.nombre}}</span>
                <span>\${{item.precio * item.cantidad}}</span>
              </div>
            </div>
            <div class="total-row">
              <span class="total-label">Total:</span>
              <span class="total-amount">\${{order()!.total}}</span>
            </div>
          </div>
        </div>

        <div class="actions" *ngIf="order()!.status !== 'entregado' && order()!.status !== 'cancelado'">
          <button class="btn-help">
            ¿Necesitas ayuda?
          </button>
        </div>

        <div class="success-message" *ngIf="order()!.status === 'entregado'">
          <svg width="60" height="60" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" fill="#27AE60"/>
            <path d="M8 12l2 2 4-4" stroke="white" stroke-width="2" stroke-linecap="round"/>
          </svg>
          <h2>¡Pedido Entregado!</h2>
          <p>Gracias por tu compra. ¡Esperamos que disfrutes tu comida!</p>
        </div>
      </div>

      <div class="loading" *ngIf="!order()">
        <div class="spinner"></div>
        <p>Cargando información del pedido...</p>
      </div>
    </div>
  `,
  styles: [`
    .track-container {
      min-height: calc(100vh - 80px);
      background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
      padding: 40px 20px;
    }

    .track-card {
      max-width: 900px;
      margin: 0 auto;
      background: white;
      border-radius: 20px;
      padding: 40px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    }

    .header {
      text-align: center;
      margin-bottom: 40px;
      position: relative;
    }

    .btn-back {
      position: absolute;
      left: 0;
      top: 0;
      background: white;
      border: 2px solid #DA291C;
      color: #DA291C;
      padding: 10px 20px;
      border-radius: 10px;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 8px;
      font-weight: 600;
      transition: all 0.3s;
    }

    .btn-back:hover {
      background: #DA291C;
      color: white;
    }

    h1 {
      color: #292929;
      font-size: 32px;
      margin-bottom: 10px;
    }

    .order-id {
      color: #DA291C;
      font-family: monospace;
      font-size: 18px;
      font-weight: 600;
    }

    .status-timeline {
      margin: 40px 0;
      padding: 20px;
    }

    .timeline-item {
      display: flex;
      gap: 20px;
      position: relative;
      opacity: 0.4;
      transition: all 0.3s;
    }

    .timeline-item.active {
      opacity: 1;
    }

    .timeline-item.completed {
      opacity: 1;
    }

    .timeline-icon {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      background: #e0e0e0;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #666;
      flex-shrink: 0;
      transition: all 0.3s;
      z-index: 2;
    }

    .timeline-item.active .timeline-icon {
      background: #FFC72C;
      color: #292929;
      animation: pulse 2s infinite;
    }

    .timeline-item.completed .timeline-icon {
      background: #27AE60;
      color: white;
    }

    @keyframes pulse {
      0%, 100% {
        box-shadow: 0 0 0 0 rgba(255, 199, 44, 0.7);
      }
      50% {
        box-shadow: 0 0 0 10px rgba(255, 199, 44, 0);
      }
    }

    .timeline-content {
      flex: 1;
      padding: 5px 0;
    }

    .timeline-content h3 {
      margin: 0 0 5px 0;
      color: #292929;
      font-size: 18px;
    }

    .timeline-content p {
      margin: 0;
      color: #666;
      font-size: 14px;
    }

    .timeline-line {
      width: 2px;
      height: 40px;
      background: #e0e0e0;
      margin-left: 24px;
      transition: all 0.3s;
    }

    .timeline-line.completed {
      background: #27AE60;
    }

    .order-info {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin-top: 40px;
    }

    .info-card {
      background: #f8f9fa;
      padding: 25px;
      border-radius: 15px;
    }

    .info-card h3 {
      margin: 0 0 20px 0;
      color: #292929;
      font-size: 18px;
      border-bottom: 2px solid #FFC72C;
      padding-bottom: 10px;
    }

    .info-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 12px;
    }

    .label {
      color: #666;
      font-weight: 500;
    }

    .value {
      color: #292929;
      font-weight: 600;
    }

    .value.estimated {
      color: #DA291C;
    }

    .value.points {
      color: #4CAF50;
      font-weight: 700;
    }

    .items-summary {
      margin-bottom: 15px;
    }

    .summary-item {
      display: flex;
      justify-content: space-between;
      padding: 10px 0;
      border-bottom: 1px solid #e0e0e0;
      font-size: 14px;
    }

    .total-row {
      display: flex;
      justify-content: space-between;
      margin-top: 15px;
      padding-top: 15px;
      border-top: 2px solid #DA291C;
    }

    .total-label {
      font-size: 18px;
      font-weight: 600;
      color: #292929;
    }

    .total-amount {
      font-size: 24px;
      font-weight: 700;
      color: #DA291C;
    }

    .actions {
      margin-top: 30px;
      text-align: center;
    }

    .btn-help {
      background: white;
      border: 2px solid #DA291C;
      color: #DA291C;
      padding: 15px 40px;
      border-radius: 10px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
    }

    .btn-help:hover {
      background: #DA291C;
      color: white;
      transform: translateY(-2px);
    }

    .success-message {
      text-align: center;
      margin-top: 30px;
      padding: 30px;
      background: #F0FFF4;
      border-radius: 15px;
      animation: slideUp 0.5s ease-out;
    }

    .success-message svg {
      margin-bottom: 15px;
    }

    .success-message h2 {
      color: #27AE60;
      margin: 10px 0;
    }

    .success-message p {
      color: #666;
      font-size: 16px;
    }

    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .loading {
      text-align: center;
      padding: 60px;
    }

    .spinner {
      width: 50px;
      height: 50px;
      border: 4px solid #f3f3f3;
      border-top-color: #DA291C;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin: 0 auto 20px;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    @media (max-width: 768px) {
      .track-card {
        padding: 30px 20px;
      }

      .order-info {
        grid-template-columns: 1fr;
      }

      .btn-back {
        position: static;
        margin-bottom: 20px;
      }

      h1 {
        font-size: 24px;
      }
    }
  `]
})
export class TrackOrderComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private orderService = inject(OrderService);
  
  order = signal<Order | null>(null);
  private statusOrder = ['pendiente', 'confirmado', 'preparando', 'en-camino', 'entregado'];

  async ngOnInit() {
    const orderId = this.route.snapshot.params['id'];
    if (orderId) {
      await this.loadOrder(orderId);
      
      // Actualizar cada 10 segundos
      interval(10000).subscribe(() => {
        this.loadOrder(orderId);
      });
    } else {
      this.router.navigate(['/']);
    }
  }

  async loadOrder(orderId: string) {
    const orderData = await this.orderService.getOrder(orderId);
    if (orderData) {
      this.order.set(orderData);
    }
  }

  isStatusActive(status: Order['status']): boolean {
    const currentStatus = this.order()?.status;
    return currentStatus === status;
  }

  isStatusCompleted(status: Order['status']): boolean {
    const currentStatus = this.order()?.status;
    if (!currentStatus) return false;
    
    const currentIndex = this.statusOrder.indexOf(currentStatus);
    const checkIndex = this.statusOrder.indexOf(status);
    
    return currentIndex > checkIndex;
  }

  formatEstimatedTime(): string {
    const estimatedTime = this.order()!.estimatedTime;
    if (!estimatedTime) return '';
    
    const date = new Date(estimatedTime);
    const now = new Date();
    const diff = Math.floor((date.getTime() - now.getTime()) / 60000);
    
    if (diff <= 0) return 'Muy pronto';
    if (diff < 60) return `${diff} minutos`;
    
    return date.toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' });
  }

  getOrderNumber(): string {
    return this.order()?.id?.slice(-8).toUpperCase() || 'N/A';
  }

  goBack() {
    this.router.navigate(['/perfil/pedidos']);
  }
}
