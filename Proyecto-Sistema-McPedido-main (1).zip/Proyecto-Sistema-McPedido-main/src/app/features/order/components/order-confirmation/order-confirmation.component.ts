import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { OrderService, Order } from '../../order.service';

@Component({
  selector: 'app-order-confirmation',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './order-confirmation.component.html',
  styleUrl: './order-confirmation.component.css'
})
export class OrderConfirmationComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private orderService = inject(OrderService);
  
  order = signal<Order | null>(null);

  async ngOnInit() {
    const orderId = this.route.snapshot.queryParams['orderId'];
    if (orderId) {
      const orderData = await this.orderService.getOrder(orderId);
      if (orderData) {
        this.order.set(orderData);
      } else {
        this.router.navigate(['/']);
      }
    } else {
      this.router.navigate(['/']);
    }
  }

  getOrderNumber(): string {
    return this.order()?.id?.slice(-8).toUpperCase() || '';
  }

  getStatusText(): string {
    return this.orderService.getStatusText(this.order()!.status);
  }

  getStatusColor(): string {
    return this.orderService.getStatusColor(this.order()!.status);
  }

  formatEstimatedTime(): string {
    const estimatedTime = this.order()!.estimatedTime;
    if (!estimatedTime) return '';
    
    const date = new Date(estimatedTime);
    const now = new Date();
    const diff = Math.floor((date.getTime() - now.getTime()) / 60000);
    
    if (diff <= 0) return 'Muy pronto';
    if (diff < 60) return diff + ' minutos';
    
    return date.toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' });
  }

  getExtrasText(extras: { nombre: string }[]): string {
    return extras.map(e => e.nombre).join(', ');
  }

  trackOrder() {
    this.router.navigate(['/track-order', this.order()!.id]);
  }

  goHome() {
    this.router.navigate(['/']);
  }
}
