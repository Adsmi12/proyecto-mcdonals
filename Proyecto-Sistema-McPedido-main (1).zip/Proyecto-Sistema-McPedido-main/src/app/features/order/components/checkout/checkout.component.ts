import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CartService } from '../../../../services/cart.service';
import { AuthService } from '../../../auth/auth.service';
import { DeliveryPickupComponent } from '../../../shared/components/delivery-pickup/delivery-pickup.component';
import { OrderService } from '../../order.service';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, DeliveryPickupComponent],
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css'
})
export class CheckoutComponent {
  private router = inject(Router);
  cartService = inject(CartService);
  authService = inject(AuthService);
  private orderService = inject(OrderService);

  showDeliveryModal = signal(false);
  deliveryInfo = signal<{ type: 'pickup' | 'delivery', location: string } | null>(null);
  paymentMethod = signal<'efectivo' | 'tarjeta' | null>(null);
  isProcessing = signal(false);

  get canProceed(): boolean {
    return !!this.deliveryInfo() && !!this.paymentMethod();
  }

  getExtrasNames(extras: { id: string; nombre: string; precio: number }[]): string {
    return extras.map(e => e.nombre).join(', ');
  }

  openDeliveryModal() {
    this.showDeliveryModal.set(true);
  }

  closeDeliveryModal() {
    this.showDeliveryModal.set(false);
  }

  onDeliverySelected(data: { type: 'pickup' | 'delivery', location: string }) {
    this.deliveryInfo.set(data);
    this.closeDeliveryModal();
  }

  selectPaymentMethod(method: 'efectivo' | 'tarjeta') {
    this.paymentMethod.set(method);
  }

  async procesarPago() {
    if (!this.canProceed) {
      return;
    }

    const user = this.authService.currentUser();
    if (!user) {
      this.router.navigate(['/login']);
      return;
    }

    this.isProcessing.set(true);

    try {
      // Simular procesamiento de pago
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Aquí se integraría con pasarela de pago real (WebPay, MercadoPago, etc.)
      const orden = {
        userId: user.id,
        items: this.cartService.cartItems(),
        total: this.cartService.totalPrice(),
        delivery: this.deliveryInfo()!,
        paymentMethod: this.paymentMethod()!,
        status: 'pendiente' as const,
        createdAt: new Date().toISOString()
      };

      // Guardar orden en Firestore
      const orderId = await this.orderService.createOrder(orden);

      // Limpiar carrito
      this.cartService.clearCart();

      // Redirigir a página de confirmación con ID de orden
      this.router.navigate(['/order-confirmation'], { queryParams: { orderId } });
    } catch (error) {
      console.error('Error al procesar pago:', error);
    } finally {
      this.isProcessing.set(false);
    }
  }

  volver() {
    this.router.navigate(['/home']);
  }
}
