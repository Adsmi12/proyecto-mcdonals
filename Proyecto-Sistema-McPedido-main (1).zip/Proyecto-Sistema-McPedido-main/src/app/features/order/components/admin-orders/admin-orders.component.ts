import { Component, OnInit, inject, signal, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderService, Order } from '../../order.service';
import { Firestore, collection, query, orderBy, limit } from '@angular/fire/firestore';
import { collectionData } from '@angular/fire/firestore';

@Component({
  selector: 'app-admin-orders',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="admin-orders">
      <div class="header">
        <h1>Gestión de Pedidos</h1>
        <div class="stats">
          <div class="stat-card">
            <div class="stat-number">{{pendingCount()}}</div>
            <div class="stat-label">Pendientes</div>
          </div>
          <div class="stat-card">
            <div class="stat-number">{{activeCount()}}</div>
            <div class="stat-label">En Proceso</div>
          </div>
          <div class="stat-card">
            <div class="stat-number">{{todayCount()}}</div>
            <div class="stat-label">Hoy</div>
          </div>
        </div>
      </div>

      <div class="filters">
        <button 
          *ngFor="let status of statusFilters" 
          [class.active]="selectedFilter() === status.value"
          (click)="selectedFilter.set(status.value)">
          {{status.label}}
        </button>
      </div>

      <div class="orders-grid">
        <div class="order-item" *ngFor="let order of filteredOrders()">
          <div class="order-header">
            <div class="order-id">#{{ getOrderNumber(order) }}</div>
            <div class="order-time">{{formatTime(order.createdAt)}}</div>
          </div>

          <div class="order-customer">
            <strong>Cliente:</strong> {{order.userId.slice(0, 8)}}...
          </div>

          <div class="order-items-list">
            <div class="item-row" *ngFor="let item of order.items">
              <span>{{item.cantidad}}x {{item.nombre}}</span>
              <span>\${{item.precio * item.cantidad}}</span>
            </div>
          </div>

          <div class="order-delivery">
            <div class="delivery-badge" [class.pickup]="order.delivery.type === 'pickup'">
              {{order.delivery.type === 'pickup' ? 'Retiro' : 'Delivery'}}
            </div>
            <span class="delivery-location">{{order.delivery.location}}</span>
          </div>

          <div class="order-total">
            <strong>Total:</strong> \${{order.total}}
          </div>

          <div class="order-status-selector">
            <select 
              [value]="order.status" 
              (change)="updateOrderStatus(order.id!, $event)"
              [style.background]="getStatusColor(order.status)">
              <option value="pendiente">Pendiente</option>
              <option value="confirmado">Confirmado</option>
              <option value="preparando">En Preparación</option>
              <option value="en-camino">En Camino</option>
              <option value="entregado">Entregado</option>
              <option value="cancelado">Cancelado</option>
            </select>
          </div>
        </div>
      </div>

      <div class="empty-state" *ngIf="filteredOrders().length === 0 && !loading()">
        <svg width="80" height="80" viewBox="0 0 24 24" fill="none">
          <rect x="3" y="3" width="18" height="18" stroke="#ccc" stroke-width="2" rx="2"/>
          <path d="M9 9h6M9 13h6M9 17h4" stroke="#ccc" stroke-width="2" stroke-linecap="round"/>
        </svg>
        <h3>No hay pedidos {{ getEmptyMessage() }}</h3>
      </div>

      <div class="loading" *ngIf="loading()">
        <div class="spinner"></div>
        <p>Cargando pedidos...</p>
      </div>
    </div>
  `,
  styles: [`
    .admin-orders {
      padding: 30px;
      max-width: 1400px;
      margin: 0 auto;
    }

    .header {
      margin-bottom: 30px;
    }

    h1 {
      color: #292929;
      font-size: 32px;
      margin-bottom: 20px;
    }

    .stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }

    .stat-card {
      background: white;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      text-align: center;
    }

    .stat-number {
      font-size: 36px;
      font-weight: 700;
      color: #DA291C;
      margin-bottom: 5px;
    }

    .stat-label {
      color: #666;
      font-size: 14px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .filters {
      display: flex;
      gap: 10px;
      margin-bottom: 30px;
      flex-wrap: wrap;
    }

    .filters button {
      padding: 10px 20px;
      border: 2px solid #e0e0e0;
      background: white;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.3s;
      font-weight: 600;
      color: #666;
    }

    .filters button:hover {
      border-color: #FFC72C;
      color: #292929;
    }

    .filters button.active {
      background: #DA291C;
      color: white;
      border-color: #DA291C;
    }

    .orders-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 20px;
    }

    .order-item {
      background: white;
      padding: 20px;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      border: 2px solid transparent;
      transition: all 0.3s;
    }

    .order-item:hover {
      border-color: #FFC72C;
      box-shadow: 0 4px 16px rgba(255, 199, 44, 0.2);
    }

    .order-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 15px;
      padding-bottom: 15px;
      border-bottom: 2px solid #f0f0f0;
    }

    .order-id {
      font-family: monospace;
      font-weight: 700;
      font-size: 18px;
      color: #292929;
    }

    .order-time {
      color: #666;
      font-size: 12px;
    }

    .order-customer {
      margin-bottom: 15px;
      color: #666;
      font-size: 14px;
    }

    .order-items-list {
      background: #f8f9fa;
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 15px;
    }

    .item-row {
      display: flex;
      justify-content: space-between;
      padding: 5px 0;
      font-size: 14px;
      color: #292929;
    }

    .order-delivery {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 15px;
    }

    .delivery-badge {
      padding: 5px 12px;
      background: #2196F3;
      color: white;
      border-radius: 5px;
      font-size: 12px;
      font-weight: 600;
    }

    .delivery-badge.pickup {
      background: #9C27B0;
    }

    .delivery-location {
      color: #666;
      font-size: 13px;
    }

    .order-total {
      font-size: 18px;
      color: #292929;
      margin-bottom: 15px;
      padding-top: 15px;
      border-top: 2px solid #f0f0f0;
    }

    .order-status-selector select {
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      color: white;
      cursor: pointer;
      font-size: 14px;
      text-align: center;
      transition: all 0.3s;
    }

    .order-status-selector select:hover {
      opacity: 0.9;
      transform: translateY(-1px);
    }

    .order-status-selector select option {
      background: white;
      color: #292929;
    }

    .empty-state {
      text-align: center;
      padding: 60px 20px;
      background: white;
      border-radius: 12px;
    }

    .empty-state svg {
      margin-bottom: 20px;
      opacity: 0.5;
    }

    .empty-state h3 {
      color: #666;
    }

    .loading {
      text-align: center;
      padding: 60px;
    }

    .spinner {
      width: 50px;
      height: 50px;
      border: 4px solid #f3f3f3;
      border-top-color: #DA291C;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin: 0 auto 20px;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    @media (max-width: 768px) {
      .orders-grid {
        grid-template-columns: 1fr;
      }

      .admin-orders {
        padding: 20px;
      }

      h1 {
        font-size: 24px;
      }
    }
  `]
})
export class AdminOrdersComponent implements OnInit {
  private firestore = inject(Firestore);
  private orderService = inject(OrderService);
  
  allOrders = signal<Order[]>([]);
  filteredOrders = signal<Order[]>([]);
  selectedFilter = signal<string>('all');
  loading = signal(true);

  statusFilters = [
    { value: 'all', label: 'Todos' },
    { value: 'pendiente', label: 'Pendientes' },
    { value: 'confirmado', label: 'Confirmados' },
    { value: 'preparando', label: 'En Preparación' },
    { value: 'en-camino', label: 'En Camino' },
    { value: 'entregado', label: 'Entregados' }
  ];

  pendingCount = signal(0);
  activeCount = signal(0);
  todayCount = signal(0);

  constructor() {
    // Filtrar cuando cambia selectedFilter
    effect(() => {
      const filter = this.selectedFilter();
      this.filterOrders();
    });
  }

  ngOnInit() {
    this.loadOrders();
  }

  loadOrders() {
    const ordersRef = collection(this.firestore, 'orders');
    const q = query(ordersRef, orderBy('createdAt', 'desc'), limit(100));
    
    collectionData(q, { idField: 'id' }).subscribe((orders: any[]) => {
      this.allOrders.set(orders as Order[]);
      this.updateStats(orders as Order[]);
      this.filterOrders();
      this.loading.set(false);
    });
  }

  filterOrders() {
    const filter = this.selectedFilter();
    const orders = this.allOrders();
    
    if (filter === 'all') {
      this.filteredOrders.set(orders);
    } else {
      this.filteredOrders.set(orders.filter(o => o.status === filter));
    }
  }

  updateStats(orders: Order[]) {
    this.pendingCount.set(orders.filter(o => o.status === 'pendiente').length);
    
    const activeStatuses = ['confirmado', 'preparando', 'en-camino'];
    this.activeCount.set(orders.filter(o => activeStatuses.includes(o.status)).length);
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    this.todayCount.set(orders.filter(o => {
      const orderDate = new Date(o.createdAt);
      orderDate.setHours(0, 0, 0, 0);
      return orderDate.getTime() === today.getTime();
    }).length);
  }

  async updateOrderStatus(orderId: string, event: Event) {
    const select = event.target as HTMLSelectElement;
    const newStatus = select.value as Order['status'];
    
    try {
      await this.orderService.updateOrderStatus(orderId, newStatus);
    } catch (error) {
      console.error('Error al actualizar estado:', error);
      alert('Error al actualizar el estado del pedido');
    }
  }

  getStatusColor(status: Order['status']): string {
    return this.orderService.getStatusColor(status);
  }

  formatTime(dateString: string): string {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return 'Hace un momento';
    if (minutes < 60) return `Hace ${minutes} min`;
    
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `Hace ${hours}h`;
    
    return date.toLocaleDateString('es-CL', { day: 'numeric', month: 'short' });
  }

  getEmptyMessage(): string {
    const filter = this.selectedFilter();
    if (filter === 'all') return '';
    const status = this.statusFilters.find(f => f.value === filter);
    return status ? status.label.toLowerCase() : '';
  }

  getOrderNumber(order: Order): string {
    return order.id?.slice(-8).toUpperCase() || 'N/A';
  }
}

