import { Component, OnInit, OnDestroy, inject, signal, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { OrderService, Order } from '../../order.service';
import { AuthService } from '../../../auth/auth.service';

@Component({
  selector: 'app-order-history',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})
export class OrderHistoryComponent implements OnInit, OnDestroy {
  private router = inject(Router);
  private orderService = inject(OrderService);
  private authService = inject(AuthService);
  
  orders = signal<Order[]>([]);
  loading = signal(true);
  private ordersSubscription: any = null;

  constructor() {}

  ngOnInit() {
    this.loadOrders();
  }

  private loadOrders() {
    // Si AuthService todavía está cargando, esperar
    if (this.authService.isLoading()) {
      setTimeout(() => this.loadOrders(), 100);
      return;
    }

    const user = this.authService.currentUser();

    if (user && user.id) {
      // Cancelar suscripción anterior si existe
      if (this.ordersSubscription) {
        this.ordersSubscription.unsubscribe();
      }
      
      // Suscribirse a los pedidos del usuario
      this.ordersSubscription = this.orderService.getUserOrders(user.id).subscribe({
        next: (orders) => {
          this.orders.set(orders);
          this.loading.set(false);
        },
        error: (error) => {
          console.error('Error al cargar pedidos:', error);
          this.loading.set(false);
        }
      });
    } else {
      this.orders.set([]);
      this.loading.set(false);
    }
  }

  ngOnDestroy() {
    // Limpiar suscripción al destruir el componente
    if (this.ordersSubscription) {
      this.ordersSubscription.unsubscribe();
    }
  }

  viewOrder(order: Order) {
    this.router.navigate(['/track-order', order.id]);
  }

  getStatusText(status: Order['status']): string {
    return this.orderService.getStatusText(status);
  }

  getStatusColor(status: Order['status']): string {
    return this.orderService.getStatusColor(status);
  }

  formatDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-CL', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  getOrderNumber(order: Order): string {
    return order.id?.slice(-8).toUpperCase() || 'N/A';
  }

  goToMenu() {
    this.router.navigate(['/home']);
  }
}
