import { Injectable, inject } from '@angular/core';
import { Firestore, collection, addDoc, doc, getDoc, updateDoc, query, where, getDocs, orderBy, deleteDoc } from '@angular/fire/firestore';
import { collectionData } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { RestaurantService } from '../../services/restaurant.service';

export interface OrderItem {
  id: string;
  nombre: string;
  precio: number;
  cantidad: number;
  imagen: string;
  ingredientesRemovidos?: string[];
  extrasAgregados?: { id: string; nombre: string; precio: number }[];
  precioUnitario?: number;

  // Campos para combos
  isCombo?: boolean;
  comboProducts?: { productId: string; productName: string; quantity: number }[];
}

export interface Order {
  id?: string;
  userId: string;
  items: OrderItem[];
  total: number;
  delivery: {
    type: 'pickup' | 'delivery';
    location: string;
  };
  paymentMethod: 'efectivo' | 'tarjeta';
  status: 'pendiente' | 'confirmado' | 'preparando' | 'en-camino' | 'entregado' | 'cancelado';
  restaurantId?: string;
  restaurantName?: string;
  createdAt: string;
  updatedAt?: string;
  estimatedTime?: string;
  pointsEarned?: number;
}

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private firestore = inject(Firestore);
  private authService = inject(AuthService);
  private restaurantService = inject(RestaurantService);
  private ordersRef = collection(this.firestore, 'orders');

  async createOrder(order: Omit<Order, 'id'>): Promise<string> {
    const pointsEarned = Math.floor(order.total / 100);

    // Si hay restaurante seleccionado, decrementar stock
    if (order.restaurantId) {
      const items = order.items.map(item => {
        // Si el item es un combo, expandir a sus productos componentes
        if (item.isCombo && item.comboProducts) {
          // Crear items individuales por cada producto del combo
          return item.comboProducts.flatMap(comboProduct =>
            Array(item.cantidad).fill({
              productId: comboProduct.productId,
              quantity: comboProduct.quantity
            })
          ).flat();
        }
        // Si no es combo, retornar normalmente
        return {
          productId: item.id,
          quantity: item.cantidad
        };
      }).flat();

      // Verificar disponibilidad de stock
      const stockCheck = await this.restaurantService.checkStockAvailability(order.restaurantId, items);
      if (!stockCheck.available) {
        throw new Error(stockCheck.message || 'Stock no disponible');
      }

      // Decrementar stock
      await this.restaurantService.decrementStock(order.restaurantId, items);
    }

    const docRef = await addDoc(this.ordersRef, {
      ...order,
      pointsEarned,
      createdAt: new Date().toISOString(),
      status: 'pendiente',
      estimatedTime: this.calculateEstimatedTime()
    });

    // Sumar puntos inmediatamente al usuario
    if (order.userId && pointsEarned > 0) {
      await this.authService.addPoints(order.userId, pointsEarned);
    }

    return docRef.id;
  }

  async getOrder(orderId: string): Promise<Order | null> {
    const docRef = doc(this.firestore, 'orders', orderId);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() } as Order;
    }
    return null;
  }

  getUserOrders(userId: string): Observable<Order[]> {
    const q = query(
      this.ordersRef,
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    return collectionData(q, { idField: 'id' }) as Observable<Order[]>;
  }

  async updateOrderStatus(orderId: string, status: Order['status']): Promise<void> {
    const docRef = doc(this.firestore, 'orders', orderId);

    // Obtener orden actual para lógica de puntos
    const orderSnap = await getDoc(docRef);
    if (!orderSnap.exists()) return;

    const orderData = orderSnap.data() as Order;
    const previousStatus = orderData.status;

    // Si se cancela la orden y no estaba cancelada antes, restar los puntos sumados
    if (status === 'cancelado' && previousStatus !== 'cancelado') {
      const pointsToDeduct = orderData.pointsEarned || Math.floor(orderData.total / 100);

      if (orderData.userId && pointsToDeduct > 0) {
        // Restar puntos (sumar valor negativo)
        await this.authService.addPoints(orderData.userId, -pointsToDeduct);
      }
    }

    // Si la orden ESTABA cancelada y se cambia a otro estado (se restaura), volver a sumar los puntos
    if (previousStatus === 'cancelado' && status !== 'cancelado') {
      const pointsToEarn = orderData.pointsEarned || Math.floor(orderData.total / 100);

      if (orderData.userId && pointsToEarn > 0) {
        await this.authService.addPoints(orderData.userId, pointsToEarn);
      }
    }

    await updateDoc(docRef, {
      status,
      updatedAt: new Date().toISOString()
    });
  }

  async deleteOrder(orderId: string): Promise<void> {
    const docRef = doc(this.firestore, 'orders', orderId);

    // Obtener datos antes de eliminar para restar puntos si es necesario
    const orderSnap = await getDoc(docRef);

    if (orderSnap.exists()) {
      const orderData = orderSnap.data() as Order;

      // Solo restar puntos si la orden NO estaba cancelada (si ya estaba cancelada, los puntos ya se restaron)
      if (orderData.status !== 'cancelado') {
        const pointsToDeduct = orderData.pointsEarned || Math.floor(orderData.total / 100);

        if (orderData.userId && pointsToDeduct > 0) {
          await this.authService.addPoints(orderData.userId, -pointsToDeduct);
        }
      }
    }

    await deleteDoc(docRef);
  }

  private calculateEstimatedTime(): string {
    const now = new Date();
    now.setMinutes(now.getMinutes() + 30); // 30 minutos estimados
    return now.toISOString();
  }

  getStatusText(status: Order['status']): string {
    const statusMap = {
      'pendiente': 'Pendiente',
      'confirmado': 'Confirmado',
      'preparando': 'En preparación',
      'en-camino': 'En camino',
      'entregado': 'Entregado',
      'cancelado': 'Cancelado'
    };
    return statusMap[status] || status;
  }

  getStatusColor(status: Order['status']): string {
    const colorMap = {
      'pendiente': '#FFA500',
      'confirmado': '#4CAF50',
      'preparando': '#2196F3',
      'en-camino': '#9C27B0',
      'entregado': '#4CAF50',
      'cancelado': '#F44336'
    };
    return colorMap[status] || '#757575';
  }
}
