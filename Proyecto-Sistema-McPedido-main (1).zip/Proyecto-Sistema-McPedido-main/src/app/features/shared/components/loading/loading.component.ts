import { Component, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-loading',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="loading-screen" *ngIf="isLoading()">
      <div class="loading-content">
        <img src="https://upload.wikimedia.org/wikipedia/commons/4/4b/McDonald%27s_logo.svg" alt="McDonald's" class="logo">
        <h1 class="loading-text">Preparando tu experiencia McDonald's</h1>
        <div class="spinner"></div>
      </div>
    </div>
  `,
  styles: [`
    .loading-screen {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: white;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 9999;
      animation: fadeOut 0.5s ease-out forwards;
      animation-delay: 0.3s;
    }

    @keyframes fadeOut {
      to {
        opacity: 0;
        visibility: hidden;
      }
    }

    .loading-content {
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 2rem;
    }

    .logo {
      width: 180px;
      height: auto;
      animation: pulse 2s ease-in-out infinite;
    }

    @keyframes pulse {
      0%, 100% {
        transform: scale(1);
      }
      50% {
        transform: scale(1.05);
      }
    }

    .loading-text {
      font-family: 'Georgia', 'Times New Roman', serif;
      font-size: 1.75rem;
      font-weight: 300;
      color: #463939;
      margin: 0;
      font-style: italic;
      letter-spacing: 0.5px;
      max-width: 500px;
      line-height: 1.4;
    }

    .spinner {
      width: 50px;
      height: 50px;
      border: 4px solid #f0f0f0;
      border-top: 4px solid #FFCC00;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    @media (max-width: 768px) {
      .logo {
        width: 140px;
      }

      .loading-text {
        font-size: 1.25rem;
        padding: 0 1rem;
      }

      .spinner {
        width: 40px;
        height: 40px;
      }
    }
  `]
})
export class LoadingComponent implements OnInit {
  isLoading = signal(true);

  ngOnInit() {
    // Ocultar después de 2 segundos
    setTimeout(() => {
      this.isLoading.set(false);
    }, 2000);
  }
}
