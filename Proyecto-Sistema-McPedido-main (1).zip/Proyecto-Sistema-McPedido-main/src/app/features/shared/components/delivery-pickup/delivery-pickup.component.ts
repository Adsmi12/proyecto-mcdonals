import { Component, output, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-delivery-pickup',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './delivery-pickup.component.html',
  styleUrl: './delivery-pickup.component.css'
})
export class DeliveryPickupComponent {
  isOpen = input<boolean>(false);
  closeModal = output<void>();
  startOrder = output<{ type: 'pickup' | 'delivery', location: string }>();

  deliveryType: 'pickup' | 'delivery' = 'pickup';
  searchLocation = '';

  onCloseModal() {
    this.closeModal.emit();
  }

  selectDeliveryType(type: 'pickup' | 'delivery') {
    this.deliveryType = type;
  }

  searchDeliveryLocation() {
    if (this.searchLocation.trim()) {
      // Búsqueda de restaurantes
    }
  }

  useCurrentLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          this.searchLocation = 'Ubicación actual';
        },
        (error) => {
          alert('No se pudo obtener tu ubicación. Por favor, verifica los permisos del navegador.');
        }
      );
    } else {
      alert('Tu navegador no soporta geolocalización.');
    }
  }

  onStartOrder() {
    if (this.searchLocation.trim()) {
      this.startOrder.emit({ type: this.deliveryType, location: this.searchLocation });
      this.onCloseModal();
    } else {
      alert('Por favor ingresa una ubicación');
    }
  }
}
