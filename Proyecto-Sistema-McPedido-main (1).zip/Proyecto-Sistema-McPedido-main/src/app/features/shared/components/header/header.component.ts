import { Component, output, viewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { CartService } from '../../../../services/cart.service';
import { AuthService } from '../../../auth/auth.service';
import { CartComponent } from '../../../product/components/cart/cart.component';
import { DeliveryPickupComponent } from '../delivery-pickup/delivery-pickup.component';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, CartComponent, DeliveryPickupComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  isMobileMenuOpen = false;
  deliveryLocation = '';
  isDeliveryModalOpen = false;
  openLoginModal = output<void>();

  cartComponent = viewChild(CartComponent);

  constructor(
    public cartService: CartService,
    public authService: AuthService
  ) { }

  toggleMobileMenu() {
    this.isMobileMenuOpen = !this.isMobileMenuOpen;
  }

  closeMobileMenu() {
    this.isMobileMenuOpen = false;
  }

  onLoginClick() {
    this.openLoginModal.emit();
  }

  async onLogout() {
    try {
      await this.authService.logout();
      // Esperar un momento para asegurar que se limpió todo
      setTimeout(() => {
        window.location.href = '/';
      }, 500);
    } catch (error) {

      alert('Error al cerrar sesión. Por favor intenta de nuevo.');
    }
  }

  openDeliveryModal() {
    this.isDeliveryModalOpen = true;
  }

  closeDeliveryModal() {
    this.isDeliveryModalOpen = false;
  }

  onStartOrder(orderData: { type: 'pickup' | 'delivery', location: string }) {
    this.deliveryLocation = orderData.location;
  }

  openCart() {
    this.cartComponent()?.toggleCart();
  }
}
