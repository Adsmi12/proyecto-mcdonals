import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ReportsService, SalesMetrics } from '../../../../services/reports.service';
import { RestaurantService } from '../../../../services/restaurant.service';
import { Order } from '../../../order/order.service';
import { Restaurant } from '../../../../interfaces/restaurant.interface';

@Component({
    selector: 'app-dashboard-reportes',
    standalone: true,
    imports: [CommonModule, FormsModule],
    templateUrl: './dashboard-reportes.html',
    styleUrl: './dashboard-reportes.css'
})
export class DashboardReportes implements OnInit {
    private reportsService = inject(ReportsService);
    private restaurantService = inject(RestaurantService);

    orders: Order[] = [];
    restaurants: Restaurant[] = [];
    metrics: SalesMetrics | null = null;
    salesByDay: { date: string; revenue: number; orderCount: number }[] = [];
    salesByStatus: { status: string; count: number; revenue: number }[] = [];

    // Filtros
    startDate: string = '';
    endDate: string = '';
    selectedRestaurantId: string = '';
    loading: boolean = false;

    ngOnInit(): void {
        // Cargar restaurantes
        this.restaurantService.getRestaurants().subscribe(restaurants => {
            this.restaurants = restaurants;
        });

        // Establecer fechas por defecto (último mes)
        const today = new Date();
        const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, today.getDate());

        this.startDate = lastMonth.toISOString().split('T')[0];
        this.endDate = today.toISOString().split('T')[0];

        // Cargar datos iniciales
        this.loadReports();
    }

    async loadReports() {
        this.loading = true;
        try {
            const startDateISO = new Date(this.startDate).toISOString();
            const endDateISO = new Date(this.endDate + 'T23:59:59').toISOString();

            if (this.selectedRestaurantId) {
                this.orders = await this.reportsService.getSalesByRestaurant(
                    this.selectedRestaurantId,
                    startDateISO,
                    endDateISO
                );
            } else {
                this.orders = await this.reportsService.getSalesByDateRange(startDateISO, endDateISO);
            }

            this.metrics = this.reportsService.getSalesMetrics(this.orders);
            this.salesByDay = this.reportsService.getSalesByDay(this.orders);
            this.salesByStatus = this.reportsService.getSalesByStatus(this.orders);
        } catch (error) {

            alert('Error al cargar los reportes');
        } finally {
            this.loading = false;
        }
    }

    formatCurrency(value: number): string {
        return '$' + value.toLocaleString('es-CL');
    }

    formatDate(dateString: string): string {
        const date = new Date(dateString);
        return date.toLocaleDateString('es-CL', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    getStatusLabel(status: string): string {
        const statusMap: { [key: string]: string } = {
            'pendiente': 'Pendiente',
            'confirmado': 'Confirmado',
            'preparando': 'En preparación',
            'en-camino': 'En camino',
            'entregado': 'Entregado',
            'cancelado': 'Cancelado'
        };
        return statusMap[status] || status;
    }

    exportToCSV() {
        if (this.orders.length === 0) {
            alert('No hay datos para exportar');
            return;
        }

        let csv = 'ID,Fecha,Cliente,Total,Estado,Método de Pago\n';

        this.orders.forEach(order => {
            const line = [
                order.id,
                order.createdAt,
                order.userId,
                order.total,
                order.status,
                order.paymentMethod
            ].join(',');
            csv += line + '\n';
        });

        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `reporte_ventas_${this.startDate}_${this.endDate}.csv`;
        a.click();
        window.URL.revokeObjectURL(url);
    }
}
