import { Component, OnInit, inject, ElementRef, AfterViewInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { Observable, combineLatest, Subject } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { Modal } from 'bootstrap';

import { OfferService } from '../../../../services/offer.service';
import { FirebaseService } from '../../../../services/firebase';
import { Offer } from '../../../../interfaces/offer.interface';
import { Producto } from '../../../../interfaces/producto.interface';
import { RestaurantService } from '../../../../services/restaurant.service';

@Component({
    selector: 'app-gestion-ofertas',
    standalone: true,
    imports: [CommonModule, ReactiveFormsModule],
    templateUrl: './gestion-ofertas.html',
    styleUrl: './gestion-ofertas.css'
})
export class GestionOfertas implements OnInit, AfterViewInit {
    private offerService = inject(OfferService);
    private firebaseService = inject(FirebaseService);
    private restaurantService = inject(RestaurantService);
    private fb = inject(FormBuilder);
    private el = inject(ElementRef);

    offers$: Observable<Offer[]>;
    productos$: Observable<Producto[]>;
    filteredProducts$!: Observable<Producto[]>; // Productos filtrados por búsqueda
    restaurants$: Observable<any[]>; // Restaurantes disponibles
    form: FormGroup;

    public offerIdEditar: string | null = null;
    public offerAEliminarId: string | null = null;

    private modalOfferBS: Modal | null = null;
    private modalEliminarBS: Modal | null = null;

    categorias: string[] = ['Hamburguesas', 'Para Acompañar', 'Pollo y McNuggets', 'Bebidas'];
    productSearchQuery = signal<string>(''); // Búsqueda de productos
    private filterTrigger = new Subject<void>(); // Trigger manual para filtrado

    constructor() {
        this.offers$ = new Observable<Offer[]>();
        this.productos$ = new Observable<Producto[]>();
        this.restaurants$ = new Observable<any[]>();
        this.form = this.fb.group({
            name: ['', Validators.required],
            description: ['', Validators.required],
            type: ['percentage', Validators.required],
            value: [0, [Validators.required, Validators.min(0)]],
            applicableTo: ['all', Validators.required],
            categoryId: [''],
            productIds: [[]],
            restaurantId: [''], // Restaurante específico (opcional)
            startDate: ['', Validators.required],
            endDate: ['', Validators.required],
            active: [true],
            imageUrl: ['']
        });
    }

    ngOnInit(): void {
        this.offers$ = this.offerService.getOffers();
        this.productos$ = this.firebaseService.getProductos();
        this.restaurants$ = this.restaurantService.getRestaurants(); // Cargar restaurantes

        // Productos filtrados: se actualiza cuando cambia productos$ o filterTrigger
        this.filteredProducts$ = combineLatest([
            this.productos$,
            this.filterTrigger.pipe(startWith(null))
        ]).pipe(
            map(([productos]) => {
                const query = this.productSearchQuery().toLowerCase().trim();
                if (!query) return productos;

                return productos.filter((p: Producto) =>
                    p.nombre.toLowerCase().includes(query) ||
                    p.descripcion?.toLowerCase().includes(query)
                );
            })
        );

        // Listener para cambios en applicableTo
        this.form.get('applicableTo')?.valueChanges.subscribe(value => {
            if (value === 'category') {
                this.form.get('categoryId')?.setValidators([Validators.required]);
                this.form.get('productIds')?.clearValidators();
            } else if (value === 'product') {
                this.form.get('productIds')?.setValidators([Validators.required]);
                this.form.get('categoryId')?.clearValidators();
            } else {
                this.form.get('categoryId')?.clearValidators();
                this.form.get('productIds')?.clearValidators();
            }
            this.form.get('categoryId')?.updateValueAndValidity();
            this.form.get('productIds')?.updateValueAndValidity();
        });
    }

    ngAfterViewInit(): void {
        const modalOfferEl = this.el.nativeElement.querySelector('#offerModal');
        const modalEliminarEl = this.el.nativeElement.querySelector('#eliminarModal');

        this.modalOfferBS = new Modal(modalOfferEl);
        this.modalEliminarBS = new Modal(modalEliminarEl);
    }

    onSearchInput(value: string) {
        this.productSearchQuery.set(value);
        this.filterTrigger.next(); // Trigger re-filtering
    }

    abrirModalCrear() {
        this.resetearFormulario();
        this.offerIdEditar = null;
        this.modalOfferBS?.show();
    }

    abrirModalEditar(offer: Offer) {
        this.cargarDatosParaEditar(offer);
        this.modalOfferBS?.show();
    }

    abrirModalEliminar(id: string) {
        this.offerAEliminarId = id;
        this.modalEliminarBS?.show();
    }

    async guardarOffer() {
        if (this.form.invalid) return;
        const datosOffer = this.form.value;

        try {
            if (this.offerIdEditar) {
                await this.offerService.updateOffer({
                    id: this.offerIdEditar,
                    ...datosOffer
                });
            } else {
                await this.offerService.addOffer(datosOffer);
            }
            this.resetearFormulario();
        } catch (error) {
            alert('Error al guardar la oferta');
        }
    }

    cargarDatosParaEditar(offer: Offer) {
        this.offerIdEditar = offer.id!;
        this.form.patchValue({
            name: offer.name,
            description: offer.description,
            type: offer.type,
            value: offer.value,
            applicableTo: offer.applicableTo,
            categoryId: offer.categoryId || '',
            productIds: offer.productIds || [],
            startDate: offer.startDate.split('T')[0],
            endDate: offer.endDate.split('T')[0],
            active: offer.active,
            imageUrl: offer.imageUrl || ''
        });
    }

    async confirmarEliminar() {
        if (!this.offerAEliminarId) return;
        try {
            await this.offerService.deleteOffer(this.offerAEliminarId);
            this.modalEliminarBS?.hide();
            this.offerAEliminarId = null;
        } catch (error) {
            alert('Error al eliminar la oferta');
        }
    }

    resetearFormulario() {
        this.form.reset({
            name: '',
            description: '',
            type: 'percentage',
            value: 0,
            applicableTo: 'all',
            categoryId: '',
            productIds: [],
            startDate: '',
            endDate: '',
            active: true,
            imageUrl: ''
        });
        this.offerIdEditar = null;
        this.modalOfferBS?.hide();
    }

    getOfferStatus(offer: Offer): string {
        const now = new Date();
        const startDate = new Date(offer.startDate);
        const endDate = new Date(offer.endDate);

        if (!offer.active) return 'Inactiva';
        if (now < startDate) return 'Programada';
        if (now > endDate) return 'Expirada';
        return 'Activa';
    }

    getStatusBadgeClass(offer: Offer): string {
        const status = this.getOfferStatus(offer);
        switch (status) {
            case 'Activa': return 'bg-success';
            case 'Programada': return 'bg-warning';
            case 'Expirada': return 'bg-secondary';
            case 'Inactiva': return 'bg-danger';
            default: return 'bg-secondary';
        }
    }

    onProductCheckChange(event: any, productId: string) {
        const productIds = this.form.get('productIds')?.value || [];
        if (event.target.checked) {
            if (!productIds.includes(productId)) {
                this.form.patchValue({
                    productIds: [...productIds, productId]
                });
            }
        } else {
            this.form.patchValue({
                productIds: productIds.filter((id: string) => id !== productId)
            });
        }
    }
}
