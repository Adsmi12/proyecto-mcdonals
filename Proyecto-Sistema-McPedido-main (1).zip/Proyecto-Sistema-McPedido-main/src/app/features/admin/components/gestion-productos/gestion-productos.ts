import { Component, OnInit, inject, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms'; 
import { Observable } from 'rxjs';

import { Modal } from 'bootstrap'; 

import { FirebaseService } from '../../../../services/firebase';
import { Producto } from '../../../../interfaces/producto.interface';

@Component({
  selector: 'app-gestion-productos',
  standalone: true, 
  imports: [
    CommonModule,        
    ReactiveFormsModule  
  ],
  templateUrl: './gestion-productos.html',
  styleUrl: './gestion-productos.css'
})
export class GestionProductos implements OnInit, AfterViewInit { 

  private firebaseService = inject(FirebaseService);
  private fb = inject(FormBuilder);
  private el = inject(ElementRef); // para obtener el elemento HTML

  productos$: Observable<Producto[]>;
  form: FormGroup;
  
  // --- variables estado de los modales ---
  public productoIdEditar: string | null = null;
  public productoAEliminarId: string | null = null;

  // referencias a los modales de bootstrap
  private modalProductoBS: Modal | null = null;
  private modalEliminarBS: Modal | null = null;
  
  constructor() {
    this.productos$ = new Observable<Producto[]>();
    this.form = this.fb.group({
      nombre: ['', Validators.required],
      descripcion: ['', Validators.required],
      precio: [0, [Validators.required, Validators.min(0.01)]], 
      categoria: ['', Validators.required],
      fotoUrl: [''],
      ingredientes: this.fb.array([]) 
    });
  }

  ngOnInit(): void {
    this.productos$ = this.firebaseService.getProductos();
  }

  // inicializar modals (crear y eliminar)
  ngAfterViewInit(): void {
    const modalProductoEl = this.el.nativeElement.querySelector('#productoModal');
    const modalEliminarEl = this.el.nativeElement.querySelector('#eliminarModal');
    
    this.modalProductoBS = new Modal(modalProductoEl);
    this.modalEliminarBS = new Modal(modalEliminarEl);
  }

  // --- manejo de ingredientes ---
  
  get ingredientesArray() {
    return this.form.get('ingredientes') as FormArray;
  }
  agregarIngrediente() {
    this.ingredientesArray.push(this.fb.group({ nombre: ['', Validators.required], imagenUrl: [''] }));
  }
  eliminarIngrediente(index: number) {
    this.ingredientesArray.removeAt(index);
  }



  abrirModalCrear() {
    this.resetearFormulario();
    this.productoIdEditar = null;
    this.modalProductoBS?.show(); 
  }

  abrirModalEditar(producto: Producto) {
    this.cargarDatosParaEditar(producto);
    this.modalProductoBS?.show(); 
  }

  abrirModalEliminar(id: string) {
    this.productoAEliminarId = id;
    this.modalEliminarBS?.show(); 
  }



  async guardarProducto() {
    if (this.form.invalid) return;
    const datosProducto = this.form.value;

    try {
      if (this.productoIdEditar) {
        await this.firebaseService.updateProducto({ id: this.productoIdEditar, ...datosProducto });
      } else {
        await this.firebaseService.addProducto(datosProducto);
      }
      this.resetearFormulario();
    } catch (error) {
      alert('Error al guardar el producto');
    }
  }

  cargarDatosParaEditar(producto: Producto) {
    this.productoIdEditar = producto.id!;
    this.form.reset(); 
    this.ingredientesArray.clear(); 
    this.form.patchValue({ ...producto }); 
    if (producto.ingredientes && producto.ingredientes.length > 0) {
      producto.ingredientes.forEach(ing => this.ingredientesArray.push(this.fb.group({ ...ing })));
    }
  }

  async confirmarEliminar() {
    if (!this.productoAEliminarId) return;
    try {
      await this.firebaseService.deleteProducto(this.productoAEliminarId);
      this.modalEliminarBS?.hide();
      this.productoAEliminarId = null;
    } catch (error) {
      alert('Error al eliminar el producto');
    }
  }

  resetearFormulario() {
    this.form.reset({
      nombre: '', descripcion: '', precio: 0, categoria: '', fotoUrl: ''
    });
    this.ingredientesArray.clear();
    this.productoIdEditar = null;
    this.modalProductoBS?.hide(); 
  }
}