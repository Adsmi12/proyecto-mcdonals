import { Component, OnInit, inject, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { Observable } from 'rxjs';
import { Modal } from 'bootstrap';

import { RestaurantService } from '../../../../services/restaurant.service';
import { FirebaseService } from '../../../../services/firebase';
import { Restaurant, RestaurantProduct } from '../../../../interfaces/restaurant.interface';
import { Producto } from '../../../../interfaces/producto.interface';

@Component({
    selector: 'app-gestion-restaurantes',
    standalone: true,
    imports: [CommonModule, ReactiveFormsModule],
    templateUrl: './gestion-restaurantes.html',
    styleUrl: './gestion-restaurantes.css'
})
export class GestionRestaurantes implements OnInit, AfterViewInit {
    private restaurantService = inject(RestaurantService);
    private firebaseService = inject(FirebaseService);
    private fb = inject(FormBuilder);
    private el = inject(ElementRef);

    restaurants$: Observable<Restaurant[]>;
    productos$: Observable<Producto[]>;
    form: FormGroup;

    public restaurantIdEditar: string | null = null;
    public restaurantAEliminarId: string | null = null;

    private modalRestaurantBS: Modal | null = null;
    private modalEliminarBS: Modal | null = null;

    constructor() {
        this.restaurants$ = new Observable<Restaurant[]>();
        this.productos$ = new Observable<Producto[]>();
        this.form = this.fb.group({
            name: ['', Validators.required],
            address: ['', Validators.required],
            phone: ['', Validators.required],
            products: this.fb.array([])
        });
    }

    ngOnInit(): void {
        this.restaurants$ = this.restaurantService.getRestaurants();
        this.productos$ = this.firebaseService.getProductos();
    }

    ngAfterViewInit(): void {
        const modalRestaurantEl = this.el.nativeElement.querySelector('#restaurantModal');
        const modalEliminarEl = this.el.nativeElement.querySelector('#eliminarModal');

        this.modalRestaurantBS = new Modal(modalRestaurantEl);
        this.modalEliminarBS = new Modal(modalEliminarEl);
    }

    get productsArray() {
        return this.form.get('products') as FormArray;
    }

    agregarProducto() {
        this.productsArray.push(this.fb.group({
            productId: ['', Validators.required],
            localPrice: [null],
            stock: [0, [Validators.required, Validators.min(0)]],
            available: [true]
        }));
    }

    eliminarProducto(index: number) {
        this.productsArray.removeAt(index);
    }

    abrirModalCrear() {
        this.resetearFormulario();
        this.restaurantIdEditar = null;
        this.modalRestaurantBS?.show();
    }

    abrirModalEditar(restaurant: Restaurant) {
        this.cargarDatosParaEditar(restaurant);
        this.modalRestaurantBS?.show();
    }

    abrirModalEliminar(id: string) {
        this.restaurantAEliminarId = id;
        this.modalEliminarBS?.show();
    }

    async guardarRestaurant() {
        if (this.form.invalid) return;
        const datosRestaurant = this.form.value;

        try {
            if (this.restaurantIdEditar) {
                await this.restaurantService.updateRestaurant({
                    id: this.restaurantIdEditar,
                    ...datosRestaurant
                });
            } else {
                await this.restaurantService.addRestaurant(datosRestaurant);
            }
            this.resetearFormulario();
        } catch (error) {
            alert('Error al guardar el restaurante');
        }
    }

    cargarDatosParaEditar(restaurant: Restaurant) {
        this.restaurantIdEditar = restaurant.id!;
        this.form.reset();
        this.productsArray.clear();

        this.form.patchValue({
            name: restaurant.name,
            address: restaurant.address,
            phone: restaurant.phone
        });

        if (restaurant.products && restaurant.products.length > 0) {
            restaurant.products.forEach(prod => {
                this.productsArray.push(this.fb.group({
                    productId: [prod.productId, Validators.required],
                    localPrice: [prod.localPrice],
                    stock: [prod.stock, [Validators.required, Validators.min(0)]],
                    available: [prod.available]
                }));
            });
        }
    }

    async confirmarEliminar() {
        if (!this.restaurantAEliminarId) return;
        try {
            await this.restaurantService.deleteRestaurant(this.restaurantAEliminarId);
            this.modalEliminarBS?.hide();
            this.restaurantAEliminarId = null;
        } catch (error) {
            alert('Error al eliminar el restaurante');
        }
    }

    resetearFormulario() {
        this.form.reset({
            name: '',
            address: '',
            phone: ''
        });
        this.productsArray.clear();
        this.restaurantIdEditar = null;
        this.modalRestaurantBS?.hide();
    }
}
