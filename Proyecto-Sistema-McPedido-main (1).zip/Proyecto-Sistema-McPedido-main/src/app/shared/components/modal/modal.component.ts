import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalService } from '../../../services/modal.service';

@Component({
    selector: 'app-modal',
    standalone: true,
    imports: [CommonModule],
    template: `
    <div class="modal-overlay" *ngIf="modalService.isVisible()" (click)="modalService.cancel()">
      <div class="modal-container" (click)="$event.stopPropagation()" [class]="'modal-' + modalService.config().type">
        <!-- Icon -->
        <div class="modal-icon">
          <svg *ngIf="modalService.config().type === 'success'" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
            <polyline points="22 4 12 14.01 9 11.01"></polyline>
          </svg>
          <svg *ngIf="modalService.config().type === 'error'" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="15" y1="9" x2="9" y2="15"></line>
            <line x1="9" y1="9" x2="15" y2="15"></line>
          </svg>
          <svg *ngIf="modalService.config().type === 'warning'" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
            <line x1="12" y1="9" x2="12" y2="13"></line>
            <line x1="12" y1="17" x2="12.01" y2="17"></line>
          </svg>
          <svg *ngIf="modalService.config().type === 'info'" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" y1="16" x2="12" y2="12"></line>
            <line x1="12" y1="8" x2="12.01" y2="8"></line>
          </svg>
        </div>

        <!-- Title -->
        <h2 class="modal-title">{{ modalService.config().title }}</h2>

        <!-- Message -->
        <p class="modal-message">{{ modalService.config().message }}</p>

        <!-- Buttons -->
        <div class="modal-buttons">
          <button 
            *ngIf="modalService.config().showCancel" 
            class="btn-cancel" 
            (click)="modalService.cancel()">
            {{ modalService.config().cancelText }}
          </button>
          <button 
            class="btn-confirm" 
            (click)="modalService.confirm()">
            {{ modalService.config().confirmText }}
          </button>
        </div>
      </div>
    </div>
  `,
    styles: [`
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.6);
      backdrop-filter: blur(4px);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 9999;
      animation: fadeIn 0.2s ease;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    .modal-container {
      background: white;
      border-radius: 16px;
      padding: 2rem;
      max-width: 400px;
      width: 90%;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      animation: slideUp 0.3s ease;
      text-align: center;
    }

    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(20px) scale(0.95);
      }
      to {
        opacity: 1;
        transform: translateY(0) scale(1);
      }
    }

    .modal-icon {
      width: 64px;
      height: 64px;
      margin: 0 auto 1.5rem;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .modal-icon svg {
      width: 40px;
      height: 40px;
    }

    .modal-success .modal-icon {
      background: #d4edda;
      color: #28a745;
    }

    .modal-error .modal-icon {
      background: #f8d7da;
      color: #dc3545;
    }

    .modal-warning .modal-icon {
      background: #fff3cd;
      color: #ffc107;
    }

    .modal-info .modal-icon {
      background: #d1ecf1;
      color: #0dcaf0;
    }

    .modal-title {
      font-size: 1.5rem;
      font-weight: 600;
      color: #292929;
      margin-bottom: 1rem;
    }

    .modal-message {
      color: #666;
      line-height: 1.6;
      margin-bottom: 2rem;
      white-space: pre-line;
    }

    .modal-buttons {
      display: flex;
      gap: 1rem;
      justify-content: center;
    }

    .btn-cancel, .btn-confirm {
      padding: 0.75rem 2rem;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s;
    }

    .btn-cancel {
      background: #f0f0f0;
      color: #666;
    }

    .btn-cancel:hover {
      background: #e0e0e0;
    }

    .btn-confirm {
      background: #DA291C;
      color: white;
    }

    .btn-confirm:hover {
      background: #c41411;
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(218, 41, 28, 0.3);
    }

    .modal-error .btn-confirm {
      background: #dc3545;
    }

    .modal-error .btn-confirm:hover {
      background: #c82333;
    }

    .modal-success .btn-confirm {
      background: #28a745;
    }

    .modal-success .btn-confirm:hover {
      background: #218838;
    }

    .modal-warning .btn-confirm {
      background: #ffc107;
      color: #000;
    }

    .modal-warning .btn-confirm:hover {
      background: #e0a800;
    }
  `]
})
export class ModalComponent {
    modalService = inject(ModalService);
}
