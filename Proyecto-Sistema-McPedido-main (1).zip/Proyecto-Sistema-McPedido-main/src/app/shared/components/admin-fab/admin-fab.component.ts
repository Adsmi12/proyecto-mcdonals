import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../../features/auth/auth.service';

interface AdminRoute {
    title: string;
    description: string;
    icon: string;
    route: string;
    color: string;
}

@Component({
    selector: 'app-admin-fab',
    standalone: true,
    imports: [CommonModule],
    template: `
    <!-- Botón Flotante (solo visible para admin) -->
    <div class="admin-fab-container" *ngIf="authService.isAdmin()">
      <button class="fab-button" (click)="togglePanel()" [class.active]="showPanel()">
        <svg *ngIf="!showPanel()" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 2v20M2 12h20"/>
        </svg>
        <svg *ngIf="showPanel()" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
        <span class="fab-text">Gestionar</span>
      </button>
    </div>

    <!-- Panel de Gestión -->
    <div class="admin-panel-overlay" *ngIf="showPanel()" (click)="closePanel()">
      <div class="admin-panel" (click)="$event.stopPropagation()">
        <div class="panel-header">
          <h2>🔧 Panel de Administración</h2>
          <p>Gestiona tu negocio desde aquí</p>
        </div>

        <div class="admin-grid">
          <div 
            *ngFor="let route of adminRoutes" 
            class="admin-card"
            [style.border-left-color]="route.color"
            (click)="navigateTo(route.route)">
            <div class="card-icon" [style.background]="route.color + '20'" [style.color]="route.color">
              {{ route.icon }}
            </div>
            <div class="card-content">
              <h3>{{ route.title }}</h3>
              <p>{{ route.description }}</p>
            </div>
            <div class="card-arrow">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </div>
          </div>
        </div>

        <button class="close-panel-btn" (click)="closePanel()">
          Cerrar
        </button>
      </div>
    </div>
  `,
    styles: [`
    /* Botón Flotante */
    .admin-fab-container {
      position: fixed;
      bottom: 2rem;
      right: 2rem;
      z-index: 9998;
    }

    .fab-button {
      width: 140px;
      height: 56px;
      background: linear-gradient(135deg, #DA291C 0%, #c41411 100%);
      border: none;
      border-radius: 28px;
      color: white;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      padding: 0 1.5rem;
      box-shadow: 0 8px 24px rgba(218, 41, 28, 0.4);
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      font-weight: 600;
      font-size: 0.95rem;
    }

    .fab-button:hover {
      transform: translateY(-4px) scale(1.05);
      box-shadow: 0 12px 32px rgba(218, 41, 28, 0.5);
    }

    .fab-button.active {
      background: linear-gradient(135deg, #c41411 0%, #a01010 100%);
      transform: rotate(90deg);
    }

    .fab-button svg {
      width: 24px;
      height: 24px;
    }

    .fab-text {
      font-weight: 600;
    }

    /* Overlay */
    .admin-panel-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.7);
      backdrop-filter: blur(8px);
      z-index: 9999;
      display: flex;
      align-items: center;
      justify-content: center;
      animation: fadeIn 0.3s ease;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    /* Panel */
    .admin-panel {
      background: white;
      border-radius: 24px;
      padding: 2.5rem;
      max-width: 900px;
      width: 90%;
      max-height: 85vh;
      overflow-y: auto;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      animation: slideUp 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    }

    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(40px) scale(0.95);
      }
      to {
        opacity: 1;
        transform: translateY(0) scale(1);
      }
    }

    .panel-header {
      text-align: center;
      margin-bottom: 2.5rem;
      padding-bottom: 1.5rem;
      border-bottom: 2px solid #f0f0f0;
    }

    .panel-header h2 {
      font-size: 2rem;
      color: #292929;
      margin-bottom: 0.5rem;
      font-weight: 700;
    }

    .panel-header p {
      color: #666;
      font-size: 1rem;
    }

    /* Grid de Cards */
    .admin-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 1.5rem;
      margin-bottom: 2rem;
    }

    .admin-card {
      background: white;
      border: 2px solid #e0e0e0;
      border-left: 4px solid;
      border-radius: 16px;
      padding: 1.5rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 1rem;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      position: relative;
      overflow: hidden;
    }

    .admin-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(135deg, transparent 0%, rgba(255,255,255,0.1) 100%);
      opacity: 0;
      transition: opacity 0.3s;
    }

    .admin-card:hover {
      transform: translateY(-8px) scale(1.02);
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.15);
      border-color: currentColor;
    }

    .admin-card:hover::before {
      opacity: 1;
    }

    .card-icon {
      width: 60px;
      height: 60px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2rem;
      flex-shrink: 0;
      transition: transform 0.3s;
    }

    .admin-card:hover .card-icon {
      transform: scale(1.1) rotate(5deg);
    }

    .card-content {
      flex: 1;
    }

    .card-content h3 {
      font-size: 1.2rem;
      color: #292929;
      margin-bottom: 0.3rem;
      font-weight: 600;
    }

    .card-content p {
      color: #666;
      font-size: 0.9rem;
      line-height: 1.4;
    }

    .card-arrow {
      width: 24px;
      height: 24px;
      color: #999;
      transition: all 0.3s;
    }

    .admin-card:hover .card-arrow {
      color: inherit;
      transform: translateX(4px);
    }

    .card-arrow svg {
      width: 100%;
      height: 100%;
    }

    /* Botón Cerrar */
    .close-panel-btn {
      width: 100%;
      padding: 1rem;
      background: #f0f0f0;
      border: none;
      border-radius: 12px;
      color: #666;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s;
    }

    .close-panel-btn:hover {
      background: #e0e0e0;
      color: #292929;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .admin-panel {
        padding: 2rem 1.5rem;
        width: 95%;
      }

      .admin-grid {
        grid-template-columns: 1fr;
      }

      .panel-header h2 {
        font-size: 1.5rem;
      }

      .fab-button {
        width: 120px;
        height: 50px;
        font-size: 0.85rem;
      }
    }
  `]
})
export class AdminFabComponent {
    authService = inject(AuthService);
    private router = inject(Router);

    showPanel = signal(false);

    adminRoutes: AdminRoute[] = [
        {
            title: 'Panel de Pedidos',
            description: 'Gestiona y monitorea todos los pedidos del sistema',
            icon: '📋',
            route: '/admin-orders',
            color: '#FFA726'
        },
        {
            title: 'Gestión de Restaurantes',
            description: 'Administra restaurantes, productos, stock y precios locales',
            icon: '🏠',
            route: '/gestion-restaurantes',
            color: '#FF6B6B'
        },
        {
            title: 'Gestión de Ofertas',
            description: 'Crea y administra promociones y descuentos especiales',
            icon: '🎁',
            route: '/gestion-ofertas',
            color: '#4ECDC4'
        },
        {
            title: 'Dashboard de Reportes',
            description: 'Analiza ventas, reportes y métricas del negocio',
            icon: '📊',
            route: '/dashboard-reportes',
            color: '#95E1D3'
        }
    ];

    togglePanel() {
        this.showPanel.update(v => !v);
    }

    closePanel() {
        this.showPanel.set(false);
    }

    navigateTo(route: string) {
        this.router.navigate([route]);
        this.closePanel();
    }
}
