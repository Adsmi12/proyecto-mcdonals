# Historial de Cambios

## Implementado

### Backend y Firebase
- Integración completa con Firebase
  - Firestore para persistencia de datos
  - Firebase Authentication
  - Configuración mediante environment.ts
 
### Autenticación y Seguridad

- Login y registro con Email/Password

- OAuth con Google y Facebook

- Resolución de conflictos entre cuentas OAuth

- Vinculación y desvinculación de cuentas

- Monitoreo de sesiones simultáneas

- AuthGuard y AdminGuard para control de acceso por roles

### Usuarios y Perfil

- Sistema de perfil con rutas anidadas

- Gestión de cuenta (eliminación, vinculación OAuth)

- Modal de cambio de contraseña

- Visualización y gestión de puntos de fidelidad

### Catálogo y Experiencia de Compra

- Catálogo dinámico de productos

- Búsqueda de productos reactiva

- Filtrado por categorías y restaurante

- Soporte para ofertas y combos

### Personalización de Productos

- Personalización de hamburguesas (ingredientes removidos y extras)

- Personalización específica para productos de pollo

- Persistencia de personalización en el carrito

### Carrito de Compras

- Carrito reactivo con Angular Signals

- Soporte para combos

- Cálculo automático de totales

- Gestión de cantidades y eliminación de ítems

### Pedidos

- Checkout con selección de método de pago

- Confirmación de pedido

- Historial de pedidos

- Seguimiento de pedidos en tiempo real

- Actualización de estado de pedidos

- Integración con sistema de puntos

### Sistema de Fidelidad

- Acumulación automática de puntos por pedido

- Visualización de puntos del usuario

- Ajuste de puntos según estado del pedido

### Panel de Administración

- Gestión de productos (CRUD)

- Gestión de ofertas y combos

- Gestión de restaurantes e inventario

- Gestión de pedidos

- Dashboard con métricas de ventas

- Exportación de reportes en formato CSV

### Servicios Compartidos

- CartService con soporte de combos y personalización

- OrderService con CRUD completo y tracking de estado

- FirebaseService para productos

- ToastService para notificaciones

### Migración de Datos

- Componente de migración de productos a Firestore

- Script utilitario migrate-products.ts

- Documentación de migración incluida

### UI / UX

- Diseño responsive (mobile, tablet, desktop)

- Animaciones en carrito y modales

- Componentes de loading y toast

- Floating Action Button (Admin)

## Productos en Catálogo

### Hamburguesas (8)
- Big Mac - $6.590
- Cuarto de Libra - $6.990
- McNífica - $6.990
- Doble Cuarto de Libra - $8.990
- McRoyal Deluxe - $4.790
- Triple Mac - $6.490
- Hamburguesa Simple - $2.490
- Cheeseburger - $2.990

### Para Acompañar (3)
- Papas Medianas - $2.390
- Papas Grandes - $2.490
- Empanadas - $2.190

### Pollo y McNuggets (4)
- Chicken kids 4 piezas - $1.860
- McNuggets 10 piezas - $4.990
- McNuggets 20 piezas - $9.590
- McPollo - $5.690

### Bebidas (5)
- Coca Cola Mediana - $2.090
- Coca Cola Grande - $2.190
- Sprite sin azúcar grande - $2.190
- Jugo de Manzana grande - $2.490
- Fanta Zero grande - $2.190

## Notas Técnicas

### Arquitectura
- Standalone Components (Angular 20+)
- Signals para manejo de estado reactivo
- Services con providedIn: 'root'
- Lazy loading preparado para rutas futuras

### Dependencias Principales
```json
{
  "@angular/core": "^20.3.8",
  "@angular/common": "^20.3.8",
  "@angular/router": "^20.3.8",
  "typescript": "~5.9.3"
}
```

### CDN de Imágenes
- API Middleware: `https://api-middleware-mcd.mcdonaldscupones.com/`
- CloudFront: `https://d2umxhib5z7frz.cloudfront.net/`

---

**Última actualización**: 14 de Diciembre, 2025
