# Migración de Productos a Firestore

## Instrucciones para migrar productos hardcodeados a Firestore

### Opción 1: Usar la consola del navegador

1. Abre la aplicación en el navegador
2. Abre la consola de desarrollador (F12)
3. Copia y pega este código:

```javascript
// Script de migración de productos a Firestore
async function migrateProducts() {
  const { collection, addDoc, getFirestore } = await import('firebase/firestore');
  const firestore = getFirestore();
  const productosRef = collection(firestore, 'productos');
  
  const productos = [
    {
      nombre: 'Big Mac',
      descripcion: 'Dos hamburguesas de carne 100% vacuno, salsa especial, lechuga, queso, pepinillos y cebolla en pan con sésamo',
      precio: 6590,
      fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Big Mac.png/200/200/original?country=cl',
      categoria: 'Hamburguesas',
      ingredientes: []
    },
    {
      nombre: 'Cuarto de Libra',
      descripcion: 'Carne 100% vacuno, queso cheddar, cebolla, pepinillos, ketchup y mostaza',
      precio: 6990,
      fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Cuarto de Libra con Queso.png/200/200/original?country=cl',
      categoria: 'Hamburguesas',
      ingredientes: []
    },
    {
      nombre: 'McPollo',
      descripcion: 'Pollo crujiente, lechuga fresca y mayonesa en un suave pan',
      precio: 5690,
      fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$qvX3kXZy/200/200/original?country=cl',
      categoria: 'Pollo y McNuggets',
      ingredientes: []
    },
    {
      nombre: 'McNífica',
      descripcion: 'Carne 100% vacuno, lechuga, tomate, cebolla, pepinillos, queso y salsa especial',
      precio: 6990,
      fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$McNifica.png/200/200/original?country=cl',
      categoria: 'Hamburguesas',
      ingredientes: []
    },
    {
      nombre: 'Doble Cuarto de Libra',
      descripcion: 'Dos carnes 100% vacuno, doble queso cheddar, cebolla, pepinillos, ketchup y mostaza',
      precio: 8990,
      fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Doble Cuarto de Libra con Queso.png/200/200/original?country=cl',
      categoria: 'Hamburguesas',
      ingredientes: []
    },
    {
      nombre: 'McRoyal Deluxe',
      descripcion: 'Carne 100% vacuno, lechuga, tomate, cebolla, pepinillos, queso y mayonesa',
      precio: 4790,
      fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Hamburguesa con Queso.png/200/200/original?country=cl',
      categoria: 'Hamburguesas',
      ingredientes: []
    },
    {
      nombre: 'Triple Mac',
      descripcion: 'Tres carnes 100% vacuno, triple queso, lechuga, cebolla, pepinillos y salsa especial',
      precio: 9490,
      fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Big Mac.png/200/200/original?country=cl',
      categoria: 'Hamburguesas',
      ingredientes: []
    },
    {
      nombre: 'Hamburguesa Simple',
      descripcion: 'Carne 100% vacuno, pepinillos, cebolla, ketchup y mostaza',
      precio: 2490,
      fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Hamburguesa regular.png/200/200/original?country=cl',
      categoria: 'Hamburguesas',
      ingredientes: []
    },
    {
      nombre: 'Cheeseburger',
      descripcion: 'Carne 100% vacuno, queso derretido, pepinillos, cebolla, ketchup y mostaza',
      precio: 2990,
      fotoUrl: 'https://api-middleware-mcd.mcdonaldscupones.com/media/image/product$Hamburguesa con Queso.png/200/200/original?country=cl',
      categoria: 'Hamburguesas',
      ingredientes: []
    },
    {
      nombre: 'Papas Medianas',
      descripcion: 'Deliciosas papas fritas doradas y crujientes',
      precio: 2390,
      fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV_370_14Feb25.png',
      categoria: 'Para Acompañar',
      ingredientes: []
    },
    {
      nombre: 'Papas Grandes',
      descripcion: 'Deliciosas papas fritas doradas y crujientes tamaño grande',
      precio: 2490,
      fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/380_05Mar25.png',
      categoria: 'Para Acompañar',
      ingredientes: []
    },
    {
      nombre: 'Empanadas',
      descripcion: 'Porcion de 3 empanadas',
      precio: 2190,
      fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/2220_05Mar25.png',
      categoria: 'Para Acompañar',
      ingredientes: []
    },
    {
      nombre: 'Chicken kids 4 piezas',
      descripcion: 'Tiernos trozos de pechuga de pollo empanizados',
      precio: 1860,
      fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV_12409_31102025.png',
      categoria: 'Pollo y McNuggets',
      ingredientes: []
    },
    {
      nombre: 'McNuggets 10 piezas',
      descripcion: 'Tiernos trozos de pechuga de pollo empanizados',
      precio: 4990,
      fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/310_05Mar25.png',
      categoria: 'Pollo y McNuggets',
      ingredientes: []
    },
    {
      nombre: 'McNuggets 20 piezas',
      descripcion: 'Tiernos trozos de pechuga de pollo empanizados',
      precio: 9590,
      fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/320_05Mar25.png',
      categoria: 'Pollo y McNuggets',
      ingredientes: []
    },
    {
      nombre: 'McPollo italiano',
      descripcion: 'Pollo crujiente, lechuga, tomate y mayonesa',
      precio: 6490,
      fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV_1633_30072025.png',
      categoria: 'Pollo y McNuggets',
      ingredientes: []
    },
    {
      nombre: 'Coca Cola Mediana',
      descripcion: 'Refrescante Coca Cola',
      precio: 2090,
      fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV_500.png',
      categoria: 'Bebidas',
      ingredientes: []
    },
    {
      nombre: 'Coca Cola Grande',
      descripcion: 'Refrescante Coca Cola tamaño grande',
      precio: 2190,
      fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/570_mop_10.png',
      categoria: 'Bebidas',
      ingredientes: []
    },
    {
      nombre: 'Sprite sin azúcar grande',
      descripcion: 'Refrescante Sprite sin azúcar',
      precio: 2190,
      fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/7087_mop_10.png',
      categoria: 'Bebidas',
      ingredientes: []
    },
    {
      nombre: 'Jugo de Manzana grande',
      descripcion: 'Jugo natural de manzana',
      precio: 2490,
      fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/DLV-108-20250814.png',
      categoria: 'Bebidas',
      ingredientes: []
    },
    {
      nombre: 'Fanta Zero grande',
      descripcion: 'Refrescante Fanta Zero sin azúcar',
      precio: 2190,
      fotoUrl: 'https://d2umxhib5z7frz.cloudfront.net/Chile/600_mop_10.png',
      categoria: 'Bebidas',
      ingredientes: []
    }
  ];

  console.log('Iniciando migración de productos...');
  let success = 0;
  let errors = 0;

  for (const producto of productos) {
    try {
      await addDoc(productosRef, producto);
      console.log(`✅ ${producto.nombre} agregado`);
      success++;
    } catch (error) {
      console.error(`❌ Error agregando ${producto.nombre}:`, error);
      errors++;
    }
  }

  console.log(`\n✅ Migración completada: ${success} productos agregados, ${errors} errores`);
}

// Ejecutar la migración
migrateProducts();
```

### Opción 2: Usar el panel de administración

1. Inicia sesión como administrador
2. Ve a la sección "Gestión de Productos"
3. Agrega productos manualmente usando el formulario

## ⚠️ IMPORTANTE

Después de migrar los productos a Firestore:
- Los productos se cargarán automáticamente desde Firestore
- La búsqueda funcionará en tiempo real
- Los cambios se reflejarán inmediatamente sin recargar
- Puedes administrar productos desde el panel admin

## Verificación

Para verificar que los productos se migraron correctamente:
1. Ve a la consola de Firebase
2. Abre Firestore Database
3. Busca la colección "productos"
4. Verifica que existan 21 documentos
