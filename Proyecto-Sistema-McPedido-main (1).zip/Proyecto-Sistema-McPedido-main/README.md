# Sistema de Pedidos McDonald's

## Descripción

McPedido es un sistema web completo de pedidos para McDonald's, desarrollado con Angular 20 y respaldado por Firebase. Permite a los usuarios explorar el menú, personalizar productos, gestionar un carrito de compras, autenticarse (incluyendo OAuth), realizar pedidos con opciones de Pickup o Delivery, hacer seguimiento del estado de sus órdenes y participar en un sistema de puntos de fidelidad.

El proyecto incluye además un panel de administración para la gestión de productos, ofertas, restaurantes, pedidos y reportes.

## Tecnologías

- **Framework**: Angular 20.3.8 (Standalone Components)
- **Lenguaje**: TypeScript 5.9.3
- **Backend / BaaS**: Firebase (Firestore + Authentication)
- **Gestión de Estado**: Angular Signals y Computed Signals
- **Autenticación**: Email/Password, Google OAuth, Facebook OAuth
- **Estilos**: CSS personalizado + Bootstrap / ng-bootstrap
- **Node.js**: 22.16.0
- **npm**: 10.9.2
- **Formateo de código**: Prettier

## Características Principales
### Funcionalidades para Usuarios

- Catálogo de Productos
  - Productos por categorías

  - Soporte para ofertas y combos

  - Búsqueda de productos en tiempo real

  - Filtrado por restaurante

- Personalización de Productos

  - Personalización de hamburguesas (ingredientes removidos y extras)

  - Personalización específica para productos de pollo

- Carrito de Compras Avanzado

  - Agregar, eliminar y modificar cantidades

  - Soporte para combos

  - Persistencia de personalizaciones por ítem

  - Cálculo automático de totales

- Autenticación y Cuenta

  - Registro e inicio de sesión

  - Login con Google y Facebook

  - Vinculación y desvinculación de cuentas

  - Monitoreo de sesiones activas

  - Gestión de perfil y eliminación de cuenta

- Pedidos

  - Checkout con selección de método de pago

  - Confirmación de pedido

  - Historial de pedidos

  - Seguimiento de pedidos en tiempo real

- Sistema de Fidelidad

  - Acumulación de puntos por compra

  - Visualización y gestión de puntos

- Pickup / Delivery

  - Selección de método de entrega

  - Búsqueda de ubicación

  - Uso de geolocalización del navegador

### Funcionalidades de Administración

- Gestión de Productos (CRUD)

- Gestión de Ofertas y Combos

- Gestión de Restaurantes

  - Inventario y stock

- Gestión de Pedidos

  - Visualización y actualización de estados

- Dashboard y Reportes

  - Métricas de ventas

  - Exportación de reportes en CSV

Todas las rutas de administración están protegidas mediante **AdminGuard**.

### Arquitectura del Proyecto

- Standalone Components (Angular moderno)

- Arquitectura reactiva basada en Signals

- Servicios con providedIn: 'root'

- Guards para control de acceso por roles

- Rutas anidadas (perfil, administración)

- Integración completa con Firebase

## Estructura del Proyecto (Resumen)

```
src/app/
├── auth/             # Autenticación, guards y modelos
├── cart/             # Carrito de compras
├── checkout/         # Proceso de pago
├── delivery-pickup/  # Modal Pickup / Delivery
├── home/             # Catálogo, búsqueda y ofertas
├── orders/           # Historial, tracking y confirmación
├── perfil/           # Perfil, cuenta y puntos
├── admin/            # Panel de administración
├── services/         # Servicios (Auth, Cart, Order, Firebase, Toast)
├── shared/           # Componentes compartidos (modales, loading, toast)
├── app.routes.ts     # Rutas de la aplicación
├── app.config.ts     # Configuración (Firebase, providers)
└── app.ts            # Componente raíz
```

## Instalación y Ejecución

### Requisitos Previos

- Node.js 22.16.0 o superior
- npm 10.9.2 o superior

### Pasos de Instalación

1. Clonar el repositorio:
```powershell
git clone https://github.com/Sonpra/Proyecto-Sistema-McPedido.git
cd Proyecto-Sistema-McPedido
```

2. Instalar dependencias:
```powershell
npm install
```

3. Iniciar el servidor de desarrollo:
```powershell
npm start
```

4. Abrir en el navegador:
```
http://localhost:4200
```

### Scripts Disponibles

- `npm start` - Inicia el servidor de desarrollo
- `npm run build` - Compila la aplicación para producción
- `npm test` - Ejecuta las pruebas unitarias
- `npm run lint` - Ejecuta el linter

## Colores de Marca

```css
--mcd-yellow: #FFCC00    /* Amarillo McDonald's */
--mcd-red: #d41b1b       /* Rojo McDonald's */
--mcd-brown: #463939     /* Marrón McDonald's */
--mcd-cream: #fff8ee     /* Crema McDonald's */
```

## Documentación Adicional

Consulta la carpeta `/documentacion` para:

- Requisitos funcionales
- Requisitos no funcionales
- Roles del equipo

## Contribuir

1. Crear una rama feature: `git checkout -b feature/nueva-funcionalidad`
2. Hacer commit de cambios: `git commit -m 'Agregar nueva funcionalidad'`
3. Push a la rama: `git push origin feature/nueva-funcionalidad`
4. Abrir un Pull Request

## Licencia

Este proyecto es parte de un trabajo académico.

## Contacto

Proyecto desarrollado por el equipo de desarrollo McPedido.
