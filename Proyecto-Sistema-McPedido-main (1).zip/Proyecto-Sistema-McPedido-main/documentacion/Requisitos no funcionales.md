RNF-01 (Seguridad - Control de Acceso): El sistema debe implementar un control de rutas que restrinja el acceso a las vistas de administrador solo a usuarios autenticados con ese rol.

RNF-02 (Seguridad - Acceso Restringido): El sistema debe restringir el acceso a vistas que requieran sesión (como "Perfil" o "Pagar") a usuarios que no hayan iniciado sesión.

RNF-03 (Robustez - Manejo de Excepciones): La aplicación debe poder controlar y manejar excepciones y casos no esperados sin "romperse" (ej. mostrar un mensaje de error amigable).

RNF-04 (Robustez - Control de Datos): El sistema debe validar los datos de entrada (ej. en formularios) para prevenir errores.

RNF-05 (Calidad de Código): El código debe seguir buenas prácticas de desarrollo, usar variables con nombres significativos y emplear estructuras de control de forma eficiente.

RNF-06 (Usabilidad): La aplicación debe tener un estilo visual de página (UI/UX) coherente y agradable para el usuario.
