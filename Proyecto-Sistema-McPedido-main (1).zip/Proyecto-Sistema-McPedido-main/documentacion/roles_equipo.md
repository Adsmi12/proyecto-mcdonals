En nuestro proyecto se decidio la implementacion de 6 roles de trabajo:
  
  Lider de Proyecto: Coordina al grupo, se comunica con el profesor y desarrolla la lógica del sistema.
  
  Scrum Master: Coordina al equipo y controla el avance del proyecto mediante la metodología ágil.
  
  Desarrollador Frontend: Implementan las vistas, componentes y navegación del sistema.
  
  Desarrollador Backend: Manejan la lógica, servicios, modelos y conexión entre frontend y backend.
  
  Diseñador Interfaz: Se encarga del aspecto visual y de la experiencia del usuario dentro del sistema.
   
  Documentador: Redacta y mantiene actualizada toda la documentación del proyecto.

La designacion de los roles fue:
  Lider de Proyecto: Andre Guerra
  
  Scrum Master: Alex Muñoz
  
  Desarrollador Frontend: Joaquin Jelvez, Criss
  
  Desarrollador Backend: Andre Guerra, Erik Correa, Benjamin Gomez
  
  Diseñador Interfaz: Alex Muñoz
  
  Documentador: Alex Muñoz

El equipo se estructuró para equilibrar las responsabilidades entre desarrollo, organización y documentación.  
Una integrante(en este caso Alex Muñoz) asume los roles de Scrum Master, Diseñadora y Documentadora, garantizando coherencia en la planificación,avances y diseño.  
Los demás integrantes se dividen entre frontend y backend, permitiendo el desarrollo simultáneo de las distintas partes del sistema.  
El Líder de Proyecto, además de coordinar, participa en la programación backend, fortaleciendo la comunicación técnica y la integración del sistema.
