RF-01 (Login): El sistema debe permitir a los usuarios (Administradores y Clientes) iniciar sesión con sus credenciales.

RF-02 (Gestión de Sesión): El sistema debe crear una sesión activa al iniciar sesión y destruirla al cerrar sesión.

RF-03 (Registro de Cliente): El sistema debe permitir a un nuevo Usuario Cliente registrarse en la plataforma para crear una cuenta (ej. solicitando nombre, email y contraseña).

RF-04 (Perfil de Usuario): El sistema debe permitir al Usuario Cliente ver y gestionar la información de su perfil.

- Administración -

RF-06 (Gestión de Menú Global): El administrador debe poder crear, leer, actualizar y eliminar (CRUD) ítems del menú global.

RF-07 (Gestión de Menú Local): El administrador debe poder asignar ítems y gestionar la disponibilidad (stock) y precios para restaurantes específicos.

RF-08 (Gestión de Atributos): El administrador debe poder definir ingredientes, precios y cantidad/disponibilidad de los productos.

RF-09 (Gestión de Ofertas): El administrador debe poder crear y gestionar ofertas y promociones.

RF-10 (Reportes de Ventas): El administrador debe poder ver reportes de ventas filtrados por restaurante.

- Cliente -

RF-11 (Catálogo/Exploración): El cliente debe poder explorar el menú (catálogo de productos) con sus precios y descripciones.

RF-12 (Personalización de Pedidos): El cliente debe poder personalizar ítems (ej. agregar extras, quitar ingredientes) en tiempo real.

RF-13 (Carrito de Compras): El cliente debe poder agregar ítems, modificar cantidades y eliminar ítems de su carrito de compras.
RF-14 (Gestión de Ubicación): El cliente debe poder seleccionar un restaurante cercano para su pedido.

RF-15 (Selección de Entrega): El cliente debe poder elegir el método de entrega (domicilio o recogida).

RF-16 (Procesamiento de Pago): El cliente debe poder proceder al pago de su orden.

RF-17 (Rastreo de Pedido): El cliente debe poder ver el estado actual de su pedido.

RF-18 (Acumulación de Puntos): El sistema debe calcular y asignar puntos de lealtad al cliente por cada compra completada.

RF-19 (Consulta de Puntos): El cliente debe poder consultar su saldo de puntos (probablemente en su perfil).
